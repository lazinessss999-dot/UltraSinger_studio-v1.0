@echo off
setlocal EnableExtensions
title UltraSinger Studio - Install

set "USROOT=%~dp0"
if "%USROOT:~-1%"=="\" set "USROOT=%USROOT:~0,-1%"

echo ============================================================
echo   UltraSinger Studio - Install, no Docker
echo   Folder: %USROOT%
echo.
echo   Everything installs INSIDE this folder.
echo   Your system Python and PATH are not touched.
echo.
echo   This takes 10 to 30 minutes, mostly downloads.
echo ============================================================
echo.

rem Check 1. The folder path must be plain Latin letters, no Cyrillic.
set "P=%USROOT%"
:charloop
if not defined P goto pathok
set "C=%P:~0,1%"
set "P=%P:~1%"
if not defined C goto charloop
set "SAFE=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789:._-\ "
set "T=%SAFE:%C=%%"
if "%T%"=="%SAFE%" goto pathbad
goto charloop
:pathok
echo [1/5] Folder path check: OK
goto step_uv
:pathbad
echo [ERROR] The folder path contains non-ASCII characters, e.g. Cyrillic.
echo Python and uv break on such paths. This was the original bug.
echo.
echo Move the whole folder to a Latin-only path, for example:
echo   H:\Tools\ultrasinger-studio   or   C:\USStudio
echo and run install.bat again.
echo.
pause
exit /b 1

:step_uv
if exist "%USROOT%\tools\uv\uv.exe" goto uv_ok
echo [1/5] Downloading uv, the package manager, ~15 MB
if not exist "%USROOT%\tools\uv" mkdir "%USROOT%\tools\uv"
certutil -urlcache -split -f "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" "%USROOT%\tools\uv\uv.zip" >nul
if errorlevel 1 (
  set "ERRMSG=Could not download uv. Check internet, antivirus, proxy. Run install.bat again."
  goto fail
)
call :unzip "%USROOT%\tools\uv\uv.zip" "%USROOT%\tools\uv"
del "%USROOT%\tools\uv\uv.zip" >nul 2>nul
if not exist "%USROOT%\tools\uv\uv.exe" (
  set "ERRMSG=Could not install uv. Check antivirus, run install.bat again."
  goto fail
)
:uv_ok
echo       uv: OK

rem All Python and caches stay inside this folder, not in C:\Users
set "UV_EXE=%USROOT%\tools\uv\uv.exe"
set "UV_PYTHON_INSTALL_DIR=%USROOT%\python"
set "UV_CACHE_DIR=%USROOT%\cache"
set "UV_LINK_MODE=copy"

:step_gpu
set "GPUQ="
set /p GPUQ="NVIDIA GPU, e.g. GTX 1070? y/n, Enter means no: "
if /i not "%GPUQ%"=="y" goto gpu_cpu
set "TORCH_BACKEND=cu126"
set "USE_GPU=1"
set "TORCH_LABEL=GPU, cu126 build with Pascal GTX 10xx support"
goto gpu_done
:gpu_cpu
set "TORCH_BACKEND=cpu"
set "USE_GPU=0"
set "TORCH_LABEL=CPU"
:gpu_done
echo       Mode: %TORCH_LABEL%
echo.

:step_py
if not exist "%USROOT%\venv\Scripts\python.exe" (
  echo [2/5] Installing Python 3.12 and local virtualenv, ~150 MB
  "%UV_EXE%" venv "%USROOT%\venv" --python 3.12
  if errorlevel 1 (
    set "ERRMSG=Could not install Python 3.12. Check internet, run install.bat again."
    goto fail
  )
)
echo       Python 3.12: OK

:step_torch
set "NEED_TORCH=1"
if "%USE_GPU%"=="1" goto torch_check
"%USROOT%\venv\Scripts\python.exe" -c "import torch" 2>nul
if not errorlevel 1 set "NEED_TORCH=0"
goto torch_check
:torch_check
if "%NEED_TORCH%"=="0" goto torch_ok
echo [3/5] Installing torch, %TORCH_LABEL%
echo       This is the biggest download, be patient.
"%UV_EXE%" pip install -p "%USROOT%\venv\Scripts\python.exe" --reinstall --torch-backend=%TORCH_BACKEND% torch==2.8.0 torchaudio==2.8.0 torchvision==0.23.0 numpy==2.4.2
if errorlevel 1 (
  set "ERRMSG=Could not install torch. Check internet, run install.bat again."
  goto fail
)
:torch_ok
echo       torch: OK

:step_deps
echo [4/5] Installing pipeline: whisperx, demucs, swift-f0, librosa
"%UV_EXE%" pip install -p "%USROOT%\venv\Scripts\python.exe" -r "%USROOT%\requirements-core.txt"
if errorlevel 1 (
  set "ERRMSG=Could not install pipeline deps. Check internet, run install.bat again."
  goto fail
)
"%UV_EXE%" pip install -p "%USROOT%\venv\Scripts\python.exe" fastapi "uvicorn[standard]" python-multipart
if errorlevel 1 (
  set "ERRMSG=Could not install the web server. Check internet, run install.bat again."
  goto fail
)
echo       Dependencies: OK

:step_ff
if exist "%USROOT%\ffmpeg\bin\ffmpeg.exe" goto ff_ok
echo [5/5] Downloading ffmpeg, ~140 MB
if not exist "%USROOT%\ffmpeg" mkdir "%USROOT%\ffmpeg"
certutil -urlcache -split -f "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" "%USROOT%\ffmpeg\ffmpeg.zip" >nul
if errorlevel 1 (
  set "ERRMSG=Could not download ffmpeg. Check internet, run install.bat again."
  goto fail
)
if not exist "%USROOT%\ffmpeg\_x" mkdir "%USROOT%\ffmpeg\_x"
call :unzip "%USROOT%\ffmpeg\ffmpeg.zip" "%USROOT%\ffmpeg\_x"
for /d %%d in ("%USROOT%\ffmpeg\_x\*") do move "%%d\bin" "%USROOT%\ffmpeg\bin" >nul 2>nul
rmdir /s /q "%USROOT%\ffmpeg\_x" >nul 2>nul
del "%USROOT%\ffmpeg\ffmpeg.zip" >nul 2>nul
if not exist "%USROOT%\ffmpeg\bin\ffmpeg.exe" (
  set "ERRMSG=Could not install ffmpeg. Check antivirus, run install.bat again."
  goto fail
)
:ff_ok
echo       ffmpeg: OK

:final
mkdir "%USROOT%\data\models" 2>nul
mkdir "%USROOT%\data\jobs" 2>nul
echo.
echo ============================================================
echo   Final check
"%USROOT%\venv\Scripts\python.exe" -c "import torch, whisperx, demucs, swift_f0, librosa" 2>nul
if errorlevel 1 (
  echo   NOTE: import check failed, look at messages above
) else (
  echo   Python + AI modules: OK
)
echo ============================================================
echo.
echo   DONE.
echo   1. Double-click start.bat, a browser opens with the UI.
echo   2. Or console: make.bat "H:\Karaoke\mp3\song.mp3"
echo.
echo   The first song downloads AI models, 1-2 GB, into data\models.
echo ============================================================
pause
exit /b 0

:fail
echo.
echo [ERROR] %ERRMSG%
echo.
pause
exit /b 1

:unzip
if not exist "%~2" mkdir "%~2"
tar -xf "%~1" -C "%~2" >nul 2>nul
if not errorlevel 1 goto :eof
powershell -NoProfile -Command "Expand-Archive -Force '%~1' '%~2'" >nul 2>nul
goto :eof
