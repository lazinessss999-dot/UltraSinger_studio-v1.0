@echo off
title UltraSinger Studio - download AI models
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" goto noenv

set "HF_HOME=%CD%\data\models\hf"
set "TORCH_HOME=%CD%\data\models\torch"
set "PYTHONUTF8=1"
set "HF_HUB_DOWNLOAD_TIMEOUT=90"
set "HF_HUB_ETAG_TIMEOUT=90"
if exist "hf_mirror.on" set "HF_ENDPOINT=https://hf-mirror.com"

echo ============================================================
echo   Downloading the AI models used by the pipeline.
echo   whisper base + small + medium and the Russian alignment
echo   model. About 1.5 GB, downloaded once.
echo   Source: huggingface.co, or ModelScope if it is blocked.
echo   Downloads resume after a break: run this file again.
echo ============================================================
echo.
if defined HF_ENDPOINT echo   Mirror: %HF_ENDPOINT%
echo.

"venv\Scripts\python.exe" web\prefetch_models.py %*
echo.
echo   Download finished. You can close this window.
pause
exit /b 0

:noenv
echo [ERROR] Environment not found. Run install.bat first.
pause
exit /b 1
