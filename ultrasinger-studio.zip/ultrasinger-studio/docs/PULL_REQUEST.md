# Pull request draft (paste into GitHub)

Use this as the PR body against [rakuri255/UltraSinger](https://github.com/rakuri255/UltraSinger).
Split into **two PRs** if you prefer a smaller review: (1) core patches,
(2) optional Windows Studio wrapper.

---

## Title

**Windows robustness, human-style charts, lyrics alignment, and an optional Studio UI**

## Summary

Field-tested patches from a Windows 10 + GTX 1070 (Pascal) setup, plus an
optional one-click Studio wrapper (browser UI, isolated venv, model
prefetch). The core changes are independent of the wrapper.

Hi @rakuri255 — thank you for UltraSinger and for being open to this work.

This PR is two layers:

1. **Core (`src/`)** — bugfixes and chart-quality changes that belong upstream.
2. **Studio (optional)** — `web/` + `.bat` installers so a Windows user can
   go from a zip to a karaoke `.txt` without Docker or a 625-package
   global install.

Full diary with file list: `CHANGELOG.md`.

## Core changes (please review these first)

- **ffmpeg on non-UTF-8 Windows** — decode as UTF-8/`errors=replace`. Fixes
  `UnicodeDecodeError: 'charmap' codec can't decode byte 0x98`.
- **Album-art mp3 is not a video** — ignore `attached_pic`; do not extract
  “audio from video” in-place (`FFmpeg cannot edit existing files in-place`).
- **Boolean CLI flags** — `--create_audio_chunks` and `--quantize_to_key`
  as flags actually turn the feature **on**. Added `--no_quantize_to_key`.
- **`--artist` / `--title` / filename** — `Artist - Title.mp3` (strip a
  leading track number) instead of `#ARTIST:Unknown Artist` when MusicBrainz
  misses.
- **`--lyrics_file`** — use the supplied words; WhisperX only **aligns**
  them (skip Whisper entirely when the file already has LRC word timings).
- **Demucs `diffq`** — `mdx_q` / `mdx_extra_q` fall back to the plain model
  when `diffq` is missing (no Windows wheel for Python 3.11+).
- **Whisper compute type** — ask ctranslate2. Pascal CC 6.1 cannot do
  efficient fp16; auto-pick `int8_float32`. Never request `float16` there.
- **Optional karaoke stems** — `--disable_karaoke` / missing Demucs stems
  must not abort the `.txt`.
- **Human-style notes** — syllable ≈ one note; long holds split to 8th-note
  `~` only; phrase breaks like a human chart (Doors *People Are Strange*).
  Hyphenation follows the **song** language, not a hardcoded locale.
- **Monotonic start beats** — overlapping Whisper/backing words used to
  write reverse beats (`199` then `182`). UltraStar Deluxe plays file order
  → empty bars and late lyrics. Clip so `previous.end ≤ next.start`, drop
  leftover `~`, sort in the writer.

## Studio wrapper (optional, can be a follow-up PR)

- Isolated venv via `uv` + Python 3.12 **inside the folder** (does not
  touch a system 3.14).
- ASCII-only `.bat` files (Cyrillic inside a `.bat` crashes Russian cmd).
- Refuse install on a non-ASCII path (`C:\Users\Денис` breaks uv).
- torch **cu126** so Pascal sm_61 still works.
- FastAPI UI: drop an MP3 → preset → live log → ZIP.
  **UI language defaults to English**, header toggle **EN / RU**.
- Lyrics search: web first (LRCLIB / lyrics.ovh / amdm.ru), then tags,
  then paste.
- Model prefetch with retries, resume, HuggingFace → ModelScope.
- Quiet torchcodec probe when versions already match; auto-repair the
  wheel if they do not.
- Docker is documented as an optional tail only — not the primary path.

## How to test

**Core only** (existing UltraSinger install):

```
python src/UltraSinger.py -i "Artist - Title.mp3" -o out --whisper small --language auto
python src/UltraSinger.py -i "song.mp3" --lyrics_file lyrics.txt --artist "Artist" --title "Title"
python src/UltraSinger.py -i "song.mp3" --disable_karaoke --disable_separation
```

Check the `.txt`:

- `#ARTIST` is the filename part before `-`, not `Unknown Artist`.
- Note start beats are **non-decreasing**.
- No 20-in-a-row `~` from an overlapping previous word.
- Lines break on phrases, not one infinite row.

**Studio** (Windows):

```
install.bat
start.bat
```

Open http://127.0.0.1:8000 — UI is English. Switch RU in the header if
you want. Drop a track, Balance preset, Create chart.

## Tested on

- Windows 10 22H2, Python 3.12 venv (system 3.14 left alone)
- CPU: i5-5200 (Broadwell, 4 cores)
- GPU: GTX 1070 8 GB, Pascal **CC 6.1**, torch 2.8 cu126
- Songs: Russian (ЛСП — Монетка) and English (The Doors — People Are Strange,
  Cage the Elephant — Ready to Let Go)

## Not in this PR / known limits

- We did not change the SwiftF0 constructor (`fmin`/`fmax` differ between
  0.1.x and 0.2.0 and do not clip `pitch_hz` anyway). C7 crumbs are
  filtered at MIDI conversion.
- Job **log lines** from the Studio wrapper are still partly Russian;
  the UltraSinger pipeline log is English. UI chrome is fully bilingual.
- No new Docker path. Existing `docker/` is untouched aside from docs.

## Checklist

- [ ] Core patches compile (`python -m py_compile src/UltraSinger.py src/modules/Ultrastar/ultrastar_writer.py`)
- [ ] `--create_audio_chunks` and `--quantize_to_key` work as flags
- [ ] Missing stems do not abort the txt
- [ ] Generated notes are monotonic in start beat
- [ ] (optional) Studio UI EN/RU toggle
