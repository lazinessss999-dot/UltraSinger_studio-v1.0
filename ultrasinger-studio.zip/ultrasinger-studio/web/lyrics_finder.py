"""Lyrics search for UltraSinger Studio.

Sources, in the order the user asked for:
  1. the internet  - LRCLIB (has synced/plain lyrics), lyrics.ovh, amdm.ru (RU)
  2. the audio file itself - ID3v2 lyrics tags (USLT/SYLT), a .lrc/.txt next to it
  3. manual input in the web UI (handled by the caller)

Everything is standard library only, so the module also works when the heavy
audio stack is not installed (e.g. for the UI preview).
"""

from __future__ import annotations

import html
import importlib.util
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

USER_AGENT_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
USER_AGENT_TOOL = "UltraSingerStudio/1.0 (local karaoke helper)"
DEFAULT_TIMEOUT = 12

_TRACK_PREFIX = re.compile(r"^\s*\d{1,3}\s*[-._)\]]\s*")
_HTML_TAG = re.compile(r"<[^>]+>")
_CHORD_LINE = re.compile(r"<b>(.*?)</b>", re.IGNORECASE)
_CHORD_TOKEN = re.compile(
    r"^[A-H][#b]?(?:m|maj|min|dim|aug|sus|add|no|M)?\d*(?:[+/][A-H][#b]?)?$"
)
_CYRILLIC = re.compile(r"[а-яё]", re.IGNORECASE)
_AMDM_LINK = re.compile(
    r'href="(?:https?://amdm\.ru)?(/akkordi/[a-z0-9_\-]+/\d+/[a-z0-9_\-]+/)"[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)

#: The vendored UltraSinger module with the (dependency free) lyrics parsing.
_VENDORED = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "UltraSinger-src",
    "src",
    "modules",
    "Speech_Recognition",
    "lyrics.py",
)


def _lyrics_module():
    if "us_lyrics_shared" not in globals():
        spec = importlib.util.spec_from_file_location("us_lyrics_shared", _VENDORED)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        globals()["us_lyrics_shared"] = module
    return globals()["us_lyrics_shared"]


def _http_get(url: str, timeout: int = DEFAULT_TIMEOUT, headers: dict = None) -> bytes:
    request = urllib.request.Request(url, headers=headers or {"User-Agent": USER_AGENT_TOOL})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _http_json(url: str, timeout: int = DEFAULT_TIMEOUT):
    return json.loads(_http_get(url, timeout).decode("utf-8", errors="replace"))


# --------------------------------------------------------------------------- #
# ID3 tags (own reader: no mutagen, no extra download for the user)
# --------------------------------------------------------------------------- #

def _decode_text_frame(data: bytes) -> str:
    if not data:
        return ""
    encoding = data[0]
    payload = data[1:]
    try:
        if encoding == 0:
            return payload.decode("latin-1", errors="replace").strip("\x00").strip()
        if encoding == 1:
            return payload.decode("utf-16", errors="replace").strip("\x00").strip()
        if encoding == 2:
            return payload.decode("utf-16-be", errors="replace").strip("\x00").strip()
        return payload.decode("utf-8", errors="replace").strip("\x00").strip()
    except Exception:
        return payload.decode("utf-8", errors="replace").strip("\x00").strip()


def _split_encoded(data: bytes, encoding: int):
    """Split a descriptor/terminated string according to the frame encoding."""
    if encoding in (1, 2):
        unit = 2
        terminator = b"\x00\x00"
    else:
        unit = 1
        terminator = b"\x00"
    for index in range(0, max(0, len(data) - unit + 1), unit):
        if data[index:index + unit] == terminator:
            return data[:index], data[index + unit:]
    return data, b""


def _synced_tag_to_lrc(data: bytes) -> str:
    """SYLT frame -> .lrc style text (timestamp format 2 = milliseconds)."""
    if len(data) < 6:
        return ""
    encoding = data[0]
    # data[1:4] = language, data[4] = timestamp format, data[5] = content type
    timestamp_format = data[4]
    _descriptor, rest = _split_encoded(data[6:], encoding)
    lines = []
    while len(rest) > 4:
        text, rest = _split_encoded(rest, encoding)
        if len(rest) < 4:
            break
        stamp = int.from_bytes(rest[:4], "big")
        rest = rest[4:]
        value = _decode_text_frame(bytes([encoding]) + text)
        if not value:
            continue
        seconds = stamp / 1000.0 if timestamp_format == 2 else stamp / 38.0
        minutes, secs = divmod(max(0.0, seconds), 60)
        lines.append(f"[{int(minutes):02d}:{secs:05.2f}]{value}")
    return "\n".join(lines)


def parse_id3(path: str) -> dict:
    """Minimal ID3v2 (USLT/SYLT/TIT2/TPE1/TALB) + ID3v1 reader."""
    result = {"title": "", "artist": "", "album": "", "lyrics": "", "synced": ""}
    try:
        with open(path, "rb") as handle:
            head = handle.read(10)
            if head[:3] != b"ID3" or len(head) < 10:
                raise ValueError("no id3v2")
            major, _minor, flags = head[3], head[4], head[5]
            size = 0
            for byte in head[6:10]:
                size = (size << 7) | (byte & 0x7F)
            body = handle.read(size)
    except Exception:
        body = b""
        major, flags = 3, 0

    if body:
        offset = 0
        if flags & 0x40:  # extended header
            if major >= 4:
                ext = 0
                for byte in body[0:4]:
                    ext = (ext << 7) | (byte & 0x7F)
                offset = ext
            else:
                offset = 4 + int.from_bytes(body[0:4], "big")
        limit = len(body)
        while offset + 10 <= limit:
            frame_id = body[offset:offset + 4]
            if not frame_id.strip(b"\x00") or frame_id == b"\x00\x00\x00\x00":
                break
            if major >= 4:
                frame_size = 0
                for byte in body[offset + 4:offset + 8]:
                    frame_size = (frame_size << 7) | (byte & 0x7F)
            else:
                frame_size = int.from_bytes(body[offset + 4:offset + 8], "big")
            if frame_size <= 0 or offset + 10 + frame_size > limit:
                break
            payload = body[offset + 10:offset + 10 + frame_size]
            offset += 10 + frame_size
            try:
                name = frame_id.decode("ascii", errors="ignore")
            except Exception:
                continue
            if name == "USLT":
                text = _decode_text_frame(bytes([payload[0]]) + payload[4:]) if len(payload) > 4 else ""
                result["lyrics"] = text or result["lyrics"]
            elif name == "SYLT":
                result["synced"] = result["synced"] or _synced_tag_to_lrc(payload)
            elif name in ("TIT2", "TT2"):
                result["title"] = result["title"] or _decode_text_frame(payload)
            elif name in ("TPE1", "TP1"):
                result["artist"] = result["artist"] or _decode_text_frame(payload)
            elif name in ("TALB", "TAL"):
                result["album"] = result["album"] or _decode_text_frame(payload)

    # ID3v1 fallback (rarely has lyrics, but gives artist/title)
    try:
        if not result["title"] or not result["artist"]:
            with open(path, "rb") as handle:
                handle.seek(0, os.SEEK_END)
                if handle.tell() > 128:
                    handle.seek(-128, os.SEEK_END)
                    tail = handle.read(128)
                    if tail[:3] == b"TAG":
                        title = tail[3:33].decode("cp1251", errors="replace").strip("\x00 ").strip()
                        artist = tail[33:63].decode("cp1251", errors="replace").strip("\x00 ").strip()
                        result["title"] = result["title"] or title
                        result["artist"] = result["artist"] or artist
                        result["album"] = result["album"] or tail[63:93].decode(
                            "cp1251", errors="replace"
                        ).strip("\x00 ").strip()
    except Exception:
        pass
    return result


def guess_artist_title(path: str, tags: dict = None) -> dict:
    """Artist/title from tags first, then from the file name."""
    lyrics = _lyrics_module()
    tags = tags if tags is not None else parse_id3(path)
    artist = lyrics.usable_name(tags.get("artist", ""))
    title = lyrics.usable_name(tags.get("title", ""))
    source = "теги файла" if (artist or title) else ""
    file_artist, file_title = lyrics.split_artist_title(path)
    if not artist:
        artist = file_artist
        if file_artist:
            source = source or "имя файла"
    if not title:
        title = file_title
        source = source or "имя файла"
    if not title:
        title = os.path.splitext(os.path.basename(path))[0].strip()
        source = source or "имя файла"
    return {
        "artist": artist,
        "title": title,
        "album": tags.get("album", ""),
        "source": source,
        "query": " ".join(part for part in (artist, title) if part).strip(),
    }


# --------------------------------------------------------------------------- #
# Local lyrics: tags and files next to the audio
# --------------------------------------------------------------------------- #

def local_lyrics(path: str) -> dict:
    """Lyrics stored in the file itself or in a .lrc/.txt next to it."""
    tags = parse_id3(path)
    if tags.get("synced") and _lyrics_module().looks_like_lyrics(tags["synced"]):
        return {"text": tags["synced"], "source": "встроенный LRC-тег (SYLT)", "synced": True,
                "artist": tags.get("artist", ""), "title": tags.get("title", "")}
    if tags.get("lyrics") and _lyrics_module().looks_like_lyrics(tags["lyrics"]):
        return {"text": tags["lyrics"], "source": "текст в теге файла (USLT)", "synced": False,
                "artist": tags.get("artist", ""), "title": tags.get("title", "")}

    stem = os.path.splitext(path)[0]
    for extension in (".lrc", ".LRC", ".txt", ".TXT"):
        candidate = stem + extension
        if os.path.isfile(candidate):
            try:
                with open(candidate, "rb") as handle:
                    data = handle.read()
            except OSError:
                continue
            text = _lyrics_module().decode_bytes(data)
            if _lyrics_module().looks_like_lyrics(text):
                parsed = _lyrics_module().parse_lyrics_text(text)
                return {
                    "text": text,
                    "source": f"файл рядом: {os.path.basename(candidate)}",
                    "synced": bool(parsed["is_lrc"]),
                    "artist": tags.get("artist", ""),
                    "title": tags.get("title", ""),
                }
    return None


# --------------------------------------------------------------------------- #
# Online sources
# --------------------------------------------------------------------------- #

def _candidate(source, artist, title, text, synced=False, extra=""):
    return {
        "source": source,
        "artist": artist or "",
        "title": title or "",
        "text": text,
        "synced": bool(synced),
        "extra": extra,
    }


def search_lrclib(artist: str, title: str, timeout: int = DEFAULT_TIMEOUT) -> list:
    """LRCLIB: free API, no key, has both synced (.lrc) and plain lyrics."""
    results = []
    base = "https://lrclib.net/api"
    headers = {"User-Agent": USER_AGENT_TOOL}
    if artist and title:
        url = f"{base}/get?" + urllib.parse.urlencode(
            {"artist_name": artist, "track_name": title}
        )
        try:
            item = _http_json(url, timeout)
            if isinstance(item, dict):
                results.append(item)
        except Exception:
            pass
    queries = []
    if artist and title:
        queries.append({"artist_name": artist, "track_name": title})
        queries.append({"q": f"{artist} {title}"})
    elif title:
        queries.append({"q": title})
    elif artist:
        queries.append({"q": artist})
    for params in queries:
        try:
            data = _http_json(f"{base}/search?" + urllib.parse.urlencode(params), timeout)
        except Exception:
            continue
        if isinstance(data, list):
            results.extend(data)
        if len(results) >= 8:
            break

    candidates, seen = [], set()
    for item in results:
        if not isinstance(item, dict):
            continue
        synced = (item.get("syncedLyrics") or "").strip()
        plain = (item.get("plainLyrics") or "").strip()
        text = synced or plain
        if not text or not _lyrics_module().looks_like_lyrics(text):
            continue
        key = re.sub(r"\s+", " ", text)[:120]
        if key in seen:
            continue
        seen.add(key)
        candidates.append(
            _candidate(
                "LRCLIB" + (" · синхронизированный" if synced else ""),
                item.get("artistName"),
                item.get("trackName"),
                text,
                synced=bool(synced),
                extra=(item.get("albumName") or ""),
            )
        )
    # synced first: line timings skip a whole whisper pass
    candidates.sort(key=lambda item: not item["synced"])
    return candidates


def search_lyrics_ovh(artist: str, title: str, timeout: int = DEFAULT_TIMEOUT) -> list:
    """lyrics.ovh: free, no key, mostly western catalogue."""
    if not artist or not title:
        return []
    url = "https://api.lyrics.ovh/v1/{}/{}".format(
        urllib.parse.quote(artist), urllib.parse.quote(title)
    )
    try:
        data = _http_json(url, timeout)
    except Exception:
        return []
    text = (data or {}).get("lyrics", "").strip()
    if not text or not _lyrics_module().looks_like_lyrics(text):
        return []
    return [_candidate("lyrics.ovh", artist, title, text)]


def _norm_key(value: str) -> str:
    return re.sub(r"[^a-zа-яё0-9]", "", (value or "").lower())


def _is_chord_line(line: str) -> bool:
    tokens = [token.strip("()[]|,.") for token in line.split() if token.strip()]
    if not tokens:
        return True
    if _CYRILLIC.search(line):
        return False
    chordy = sum(1 for token in tokens if _CHORD_TOKEN.match(token))
    if chordy == 0:
        return False
    long_words = [token for token in tokens if len(token) >= 4 and re.search(r"[a-z]{3}", token)]
    return chordy / len(tokens) >= 0.6 and not long_words


def _clean_amdm_block(block: str) -> str:
    lines = []
    for raw in block.split("\n"):
        line = html.unescape(_HTML_TAG.sub("", raw)).rstrip()
        if _is_chord_line(line):
            continue
        lines.append(line)
    return "\n".join(lines)


def search_amdm(artist: str, title: str, timeout: int = DEFAULT_TIMEOUT, limit: int = 3) -> list:
    """amdm.ru: the big Russian lyrics/chords site (Cyrillic catalogue)."""
    query = " ".join(part for part in (artist, title) if part).strip()
    if not query:
        return []
    headers = {"User-Agent": USER_AGENT_BROWSER, "Accept-Language": "ru,en;q=0.5"}
    try:
        page = _http_get(
            "https://amdm.ru/search/?" + urllib.parse.urlencode({"q": query}),
            timeout,
            headers,
        ).decode("utf-8", errors="replace")
    except Exception:
        return []

    title_norm = _norm_key(title)
    links, seen = [], set()
    for href, label in _AMDM_LINK.findall(page):
        if href in seen:
            continue
        seen.add(href)
        label_key = _norm_key(_HTML_TAG.sub("", label))
        slug_key = _norm_key(href.rstrip("/").split("/")[-1])
        score = 0
        for key in (label_key, slug_key):
            if not key or not title_norm:
                continue
            if key == title_norm:
                score = max(score, 3)
            elif key.startswith(title_norm[:6]) or title_norm.startswith(key[:6]):
                score = max(score, 2)
        # без совпадения по названию amdm отдаёт что попало - такое не берём
        if title_norm and score == 0:
            continue
        links.append((score, href))
    links.sort(key=lambda item: -item[0])

    candidates = []
    for _score, href in links[:limit * 2]:
        try:
            song_page = _http_get("https://amdm.ru" + href, timeout, headers).decode(
                "utf-8", errors="replace"
            )
        except Exception:
            continue
        block = re.search(r"<pre[^>]*>(.*?)</pre>", song_page, re.S)
        if not block:
            continue
        text = _clean_amdm_block(block.group(1)).strip()
        parsed = _lyrics_module().parse_lyrics_text(text)
        text = "\n".join(parsed["lines"])
        if not _lyrics_module().looks_like_lyrics(text):
            continue
        page_artist, page_title = "", ""
        heading = re.search(r"<h1[^>]*>(.*?)</h1>", song_page, re.S)
        if heading:
            heading_text = html.unescape(_HTML_TAG.sub("", heading.group(1))).strip()
            heading_text = re.sub(r"\s*(текст песни|слова|аккорды).*$", "", heading_text, flags=re.I)
            if " - " in heading_text:
                page_artist, page_title = [part.strip() for part in heading_text.split(" - ", 1)]
            else:
                page_title = heading_text
        candidates.append(
            _candidate(
                "amdm.ru",
                page_artist or artist,
                page_title or title,
                text,
                synced=False,
                extra="аккорды удалены на лету",
            )
        )
        if len(candidates) >= limit:
            break
    return candidates


ONLINE_SOURCES = {
    "lrclib": search_lrclib,
    "lyrics.ovh": search_lyrics_ovh,
    "amdm.ru": search_amdm,
}


def online_candidates(artist: str, title: str, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Ask all sources in parallel; returns {'candidates': [...], 'errors': [...]}."""
    candidates, errors = [], []
    workers = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        for name, function in ONLINE_SOURCES.items():
            workers.append((name, pool.submit(function, artist, title, timeout)))
        for name, future in workers:
            try:
                candidates.extend(future.result(timeout=timeout + 6) or [])
            except Exception as error:  # noqa: BLE001
                errors.append(f"{name}: {error}")

    unique, seen = [], set()
    for item in candidates:
        key = (item["source"].split(" · ")[0], re.sub(r"\s+", " ", item["text"])[:160])
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    unique.sort(key=lambda item: (not item["synced"], 0 if item["source"].startswith("LRCLIB") else 1))
    return {"candidates": unique, "errors": errors}


def find_lyrics(path: str, artist: str = "", title: str = "", order=("online", "file"),
                timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Automatic search in the requested order. Returns a result dict or None."""
    guessed = guess_artist_title(path)
    artist = (artist or guessed["artist"]).strip()
    title = (title or guessed["title"]).strip()

    for step in order:
        if step == "file":
            found = local_lyrics(path)
            if found:
                found.setdefault("artist", artist)
                found.setdefault("title", title)
                return found
        elif step == "online":
            result = online_candidates(artist, title, timeout)
            if result["candidates"]:
                best = result["candidates"][0]
                best["names"] = {"artist": artist, "title": title}
                return best
    return None
