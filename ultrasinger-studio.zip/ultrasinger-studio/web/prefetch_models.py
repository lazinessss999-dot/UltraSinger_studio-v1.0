"""Download the AI models used by the pipeline.

Why this script exists
----------------------
huggingface.co is not reachable from some networks (Russia, China, corporate
proxies). huggingface_hub then fails before a single byte is downloaded:
first it resolves the URL with a HEAD request, and only a working Hub answer
lets the download start. hf-mirror.com is usually no help either, because it
redirects files to huggingface.co (and to *.hf.co CDN hosts) instead of
serving them itself.

So models are downloaded here in two ways:
  1. through huggingface_hub (when the Hub answers) - fastest, uses the
     official cache and checksums;
  2. file by file from ModelScope (www.modelscope.cn) - it mirrors these
     repositories and serves the files itself. Files are written into the
     same HuggingFace cache layout, so after this the pipeline finds them
     locally and never touches the network again.

Downloads resume after an interruption, retry several times and switch host
on every attempt.

Usage:
    python prefetch_models.py [sets...]        (no arguments = the usual set)

Sets: whisper-tiny, whisper-base, whisper-small, whisper-medium,
      whisper-large-v3, align-ru, align-en, align-uk, all
"""

import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

REPOS = {
    "whisper-tiny": "Systran/faster-whisper-tiny",
    "whisper-base": "Systran/faster-whisper-base",
    "whisper-small": "Systran/faster-whisper-small",
    "whisper-medium": "Systran/faster-whisper-medium",
    "whisper-large-v2": "Systran/faster-whisper-large-v2",
    "whisper-large-v3": "Systran/faster-whisper-large-v3",
    "align-ru": "jonatasgrosman/wav2vec2-large-xlsr-53-russian",
    "align-en": "jonatasgrosman/wav2vec2-large-xlsr-53-english",
    "align-uk": "Yehor/wav2vec2-xls-r-300m-uk-with-small-lm",
}

#: Alignment models that whisperx 3.8.1 pulls from HuggingFace
#: (DEFAULT_ALIGN_MODELS_HF it uses for these languages; en/fr/de/es/it come
#: from torchaudio bundles and are downloaded from pytorch.org instead).
ALIGN_LANGUAGES = {
    "ja": "jonatasgrosman/wav2vec2-large-xlsr-53-japanese",
    "zh": "jonatasgrosman/wav2vec2-large-xlsr-53-chinese-zh-cn",
    "nl": "jonatasgrosman/wav2vec2-large-xlsr-53-dutch",
    "uk": "Yehor/wav2vec2-xls-r-300m-uk-with-small-lm",
    "pt": "jonatasgrosman/wav2vec2-large-xlsr-53-portuguese",
    "ru": "jonatasgrosman/wav2vec2-large-xlsr-53-russian",
    "pl": "jonatasgrosman/wav2vec2-large-xlsr-53-polish",
    "hu": "jonatasgrosman/wav2vec2-large-xlsr-53-hungarian",
    "fi": "jonatasgrosman/wav2vec2-large-xlsr-53-finnish",
    "el": "jonatasgrosman/wav2vec2-large-xlsr-53-greek",
    "tr": "mpoyraz/wav2vec2-xls-r-300m-cv7-turkish",
    "ko": "kresnik/wav2vec2-large-xlsr-korean",
    "hi": "theainerd/Wav2Vec2-large-xlsr-hindi",
    "ca": "softcatala/wav2vec2-large-xlsr-catala",
    "no": "NbAiLab/nb-wav2vec2-1b-bokmaal-v2",
    "sv": "KBLab/wav2vec2-large-voxrex-swedish",
    "ro": "gigant/romanian-wav2vec2",
    "sk": "comodoro/wav2vec2-xls-r-300m-sk-cv8",
    "hr": "classla/wav2vec2-xls-r-parlaspeech-hr",
    "cs": "comodoro/wav2vec2-xls-r-300m-cs-250",
}
for _lang, _repo in ALIGN_LANGUAGES.items():
    REPOS.setdefault(f"align-{_lang}", _repo)

DEFAULT_SETS = ["whisper-base", "whisper-small", "whisper-medium", "align-ru"]

MIRROR = "https://hf-mirror.com"
DIRECT = "https://huggingface.co"
MODELSCOPE = "https://www.modelscope.cn"
MODELSCOPE_REVISION = "master"

HF_HOME = Path(os.environ.get("HF_HOME") or Path.home() / ".cache" / "huggingface")
HUB_DIR = HF_HOME / "hub"

CHUNK = 1024 * 1024
READ_TIMEOUT = 60
ATTEMPTS_PER_HOST = 4


def log(message: str = "") -> None:
    print(message, flush=True)


def human(size: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


# --------------------------------------------------------------------------- #
# HTTP helpers
# --------------------------------------------------------------------------- #

def http_open(url: str, headers: dict | None = None, timeout: float = 30.0):
    request = urllib.request.Request(url, headers=headers or {})
    request.add_header("User-Agent", "ultrasinger-studio/1.0")
    return urllib.request.urlopen(request, timeout=timeout)


def http_json(url: str, timeout: float = 20.0):
    with http_open(url, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8", "replace"))


def reachable(url: str, timeout: float = 8.0) -> bool:
    try:
        with http_open(url, timeout=timeout) as response:
            return response.status == 200
    except Exception:
        return False


def probe(endpoint: str, timeout: float = 8.0) -> bool:
    try:
        with http_open(f"{endpoint}/api/models/Systran/faster-whisper-base",
                       timeout=timeout) as response:
            return response.status == 200 and b'"id"' in response.read(4096)
    except Exception:
        return False


def pick_endpoint() -> str:
    if os.environ.get("HF_ENDPOINT"):
        log(f"Endpoint from environment: {os.environ['HF_ENDPOINT']}")
        return os.environ["HF_ENDPOINT"]
    log("Checking huggingface.co ...")
    if probe(DIRECT):
        log("  huggingface.co answers.")
        return DIRECT
    log("  huggingface.co does not answer - switching to the mirror hf-mirror.com.")
    if probe(MIRROR):
        log("  hf-mirror.com answers.")
        return MIRROR
    log("  the mirror does not answer either; model files will be taken from ModelScope.")
    return MIRROR


# --------------------------------------------------------------------------- #
# Cache layout (the layout huggingface_hub expects, so the pipeline finds it)
# --------------------------------------------------------------------------- #

def cache_root(repo: str) -> Path:
    return HUB_DIR / ("models--" + repo.replace("/", "--"))


def cached_revision(repo: str) -> str | None:
    ref = cache_root(repo) / "refs" / "main"
    if ref.is_file():
        try:
            return ref.read_text(encoding="utf-8").strip() or None
        except Exception:
            return None
    snapshots = cache_root(repo) / "snapshots"
    if snapshots.is_dir():
        dirs = [d for d in snapshots.iterdir() if d.is_dir()]
        if dirs:
            return sorted(dirs, key=lambda d: d.stat().st_mtime)[-1].name
    return None


def in_cache(repo: str) -> bool:
    """True when the repository has at least one usable snapshot on disk."""
    revision = cached_revision(repo)
    if not revision:
        return False
    snapshot = cache_root(repo) / "snapshots" / revision
    if not snapshot.is_dir():
        return False
    files = [p for p in snapshot.rglob("*") if p.is_file()]
    return len(files) >= 3


def write_ref(repo: str, revision: str) -> None:
    refs = cache_root(repo) / "refs"
    refs.mkdir(parents=True, exist_ok=True)
    (refs / "main").write_text(revision, encoding="utf-8")


# --------------------------------------------------------------------------- #
# Source 1: huggingface_hub (official cache, checksums, resume)
# --------------------------------------------------------------------------- #

def download_via_hub(repo: str, attempts: int = 2) -> bool:
    try:
        from huggingface_hub import snapshot_download
    except Exception as error:
        log(f"  huggingface_hub is not available ({type(error).__name__})")
        return False

    for attempt in range(1, attempts + 1):
        try:
            try:
                path = snapshot_download(repo, max_workers=1, resume_download=True)
            except TypeError:
                path = snapshot_download(repo, max_workers=1)
            log(f"  huggingface_hub: OK -> {path}")
            return True
        except Exception as error:
            log(f"  huggingface_hub attempt {attempt}/{attempts}: "
                f"{type(error).__name__}: {str(error)[:200]}")
            time.sleep(min(4 * attempt, 15))
    return False


# --------------------------------------------------------------------------- #
# Source 2: ModelScope file by file
# --------------------------------------------------------------------------- #

def modelscope_files(repo: str) -> list[tuple[str, int]] | None:
    url = (f"{MODELSCOPE}/api/v1/models/{repo}/repo/files"
           f"?Revision={MODELSCOPE_REVISION}")
    try:
        data = http_json(url).get("Data") or {}
    except Exception as error:
        log(f"  ModelScope listing failed: {type(error).__name__}: {error}")
        return None
    files = []
    for item in data.get("Files") or []:
        path, size = item.get("Path"), item.get("Size")
        if not path or path.endswith("/"):
            continue
        files.append((path, int(size or 0)))
    return files or None


def modelscope_url(repo: str, path: str) -> str:
    quoted = urllib.parse.quote(path)
    return (f"{MODELSCOPE}/api/v1/models/{repo}/repo"
            f"?Revision={MODELSCOPE_REVISION}&FilePath={quoted}")


def download_stream(url: str, dest: Path, expected_size: int | None,
                    retries: int = ATTEMPTS_PER_HOST) -> bool:
    """Download url -> dest with resume; keep the partial file between tries."""
    part = dest.with_name(dest.name + ".part")
    dest.parent.mkdir(parents=True, exist_ok=True)
    last_report = 0.0

    for attempt in range(1, retries + 1):
        have = part.stat().st_size if part.exists() else 0
        if expected_size and have >= expected_size:
            break
        headers = {}
        if have:
            headers["Range"] = f"bytes={have}-"
        try:
            with http_open(url, headers, timeout=READ_TIMEOUT) as response:
                status = response.status
                if have and status != 206:
                    # the host ignored the Range header: start over
                    have = 0
                total = expected_size
                if not total:
                    length = response.headers.get("Content-Length")
                    total = (int(length) + have) if length else None
                mode = "ab" if have else "wb"
                done = have
                started = time.time()
                with open(part, mode) as handle:
                    while True:
                        block = response.read(CHUNK)
                        if not block:
                            break
                        handle.write(block)
                        done += len(block)
                        if total:
                            now = time.time()
                            if now - last_report > 5 or done >= total:
                                speed = (done - have) / max(now - started, 0.1)
                                log(f"    {done * 100 // total:3d}%  "
                                    f"{human(done)} / {human(total)}  "
                                    f"({human(speed)}/s)")
                                last_report = now
            if expected_size and part.stat().st_size != expected_size:
                log(f"    incomplete: {human(part.stat().st_size)} of "
                    f"{human(expected_size)},  continuing")
                continue
            if not expected_size and part.stat().st_size == 0:
                log("    empty file, retrying")
                continue
            part.replace(dest)
            return True
        except urllib.error.HTTPError as error:
            if error.code == 404:
                log(f"    {dest.name}: not found on ModelScope (HTTP 404)")
                return False
            log(f"    {dest.name}: HTTP {error.code}, attempt {attempt}/{retries}")
        except Exception as error:
            log(f"    {dest.name}: {type(error).__name__}: {str(error)[:120]}, "
                f"attempt {attempt}/{retries}")
        time.sleep(min(3 * attempt, 15))
    return False


def download_via_modelscope(repo: str, revision: str | None = None) -> bool:
    if not reachable(MODELSCOPE, timeout=10):
        log("  ModelScope does not answer either - no usable source.")
        return False
    files = modelscope_files(repo)
    if not files:
        log(f"  ModelScope does not have {repo}.")
        return False

    if not revision:
        digest = hashlib.sha1(
            "|".join(f"{p}:{s}" for p, s in sorted(files)).encode()).hexdigest()
        revision = "modelscope-" + digest[:16]

    snapshot = cache_root(repo) / "snapshots" / revision
    log(f"  ModelScope: {len(files)} files, revision {revision[:20]}")
    ok = True
    for index, (path, size) in enumerate(files, 1):
        target = snapshot / path
        if target.is_file() and size and target.stat().st_size == size:
            log(f"    [{index}/{len(files)}] {path}: already downloaded")
            continue
        log(f"    [{index}/{len(files)}] {path}  ({human(size)})")
        if not download_stream(modelscope_url(repo, path), target, size or None):
            ok = False
    if ok:
        write_ref(repo, revision)
        log(f"  ModelScope: OK -> {snapshot}")
    return ok


# --------------------------------------------------------------------------- #
# Per repository logic
# --------------------------------------------------------------------------- #

def fetch_repo(repo: str, endpoint: str) -> bool:
    if in_cache(repo):
        log(f"  already in the local cache ({cached_revision(repo)[:16]}), skipped")
        return True

    sources = []
    if reachable(f"{endpoint}/api/models/Systran/faster-whisper-base", timeout=8):
        sources.append("hub")
    sources.append("modelscope")

    for source in sources:
        if source == "hub":
            log("  source: huggingface_hub")
            if download_via_hub(repo):
                return True
        else:
            log("  source: ModelScope (mirrors the same repositories)")
            if download_via_modelscope(repo):
                return True
    return False


def verify_with_hub(repo: str) -> None:
    """Make sure huggingface_hub finds what we just wrote."""
    try:
        from huggingface_hub import snapshot_download
        path = snapshot_download(repo, local_files_only=True)
        log(f"  check: huggingface_hub sees the model at {path}")
    except Exception as error:
        log(f"  check: huggingface_hub cannot use the local copy yet "
            f"({type(error).__name__}), the pipeline may ask for it again")


def prefetch_nltk_punkt() -> bool:
    """nltk sentence splitter data used by whisperx alignment."""
    try:
        import nltk
    except Exception:
        log("  nltk is not installed - skipped")
        return False
    target = Path(os.environ.get("NLTK_DATA") or (HF_HOME.parent / "nltk"))
    target.mkdir(parents=True, exist_ok=True)
    ok = True
    for resource in ("punkt", "punkt_tab"):
        already = any(target.rglob(f"{resource}.zip")) or any(target.rglob(resource))
        if already:
            log(f"  nltk {resource}: already present")
            continue
        try:
            done = nltk.download(resource, download_dir=str(target), quiet=True)
            log(f"  nltk {resource}: {'OK' if done else 'not downloaded'}")
            ok = ok and bool(done)
        except Exception as error:
            log(f"  nltk {resource}: {type(error).__name__}: {str(error)[:120]}")
            ok = False
    return ok


def main(argv: list[str]) -> int:
    sets = argv or DEFAULT_SETS
    if "all" in sets:
        sets = [name for name in REPOS if name != "all"]
    unknown = [name for name in sets if name not in REPOS]
    if unknown:
        log(f"Unknown sets: {', '.join(unknown)}")
        log(f"Available: {', '.join(sorted(REPOS))}, all")
        return 2

    os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "90")
    # The metadata request is tiny: do not wait long for it, ModelScope is the fallback.
    os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "20")
    endpoint = os.environ.get("HF_ENDPOINT") or pick_endpoint()
    os.environ["HF_ENDPOINT"] = endpoint
    os.environ.setdefault("HF_HOME", str(HF_HOME))

    log("")
    log(f"Models to download: {len(sets)}  |  cache: {HUB_DIR}")
    failed = []
    for index, name in enumerate(sets, 1):
        repo = REPOS[name]
        log("")
        log(f"[{index}/{len(sets)}] {name}  ({repo})")
        if fetch_repo(repo, endpoint):
            verify_with_hub(repo)
        else:
            failed.append(name)

    log("")
    log("Text splitter data (nltk punkt):")
    prefetch_nltk_punkt()

    log("")
    if not failed:
        log("All models are in the local cache: the pipeline will not download "
            "them again and does not need huggingface.co.")
        return 0
    log(f"Not downloaded: {', '.join(failed)}")
    log("Run this script again - the downloaded parts are reused, "
        "or pick another model in the web interface.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
