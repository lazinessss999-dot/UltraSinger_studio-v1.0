"""Start UltraSinger.py as a subprocess that never shows Windows error dialogs.

When a native DLL cannot be loaded, Windows normally shows a modal message box
("entry point not found in ...dll"). For a background pipeline that box is
useless: it blocks the process, hides the real Python error and looks like a
crash to the user. SetErrorMode() turns those dialogs into ordinary Python
exceptions, which end up in the job log where they can be read and handled.

Usage:
    python pipeline_launcher.py <path to UltraSinger.py> [pipeline arguments...]
"""

import os
import runpy
import sys
from pathlib import Path

# SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX
SILENT_ERROR_MODE = 0x0001 | 0x0002 | 0x8000


def silence_native_error_dialogs() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes

        ctypes.windll.kernel32.SetErrorMode(SILENT_ERROR_MODE)
    except Exception:
        pass


def main(argv: list[str]) -> int:
    if not argv:
        print("usage: pipeline_launcher.py <path to UltraSinger.py> [args...]")
        return 2
    silence_native_error_dialogs()

    script = Path(argv[0]).resolve()
    if not script.is_file():
        print(f"pipeline_launcher: not found: {script}")
        return 2

    # UltraSinger.py imports its own package "modules", so its folder must be
    # importable and relative paths (cache, output) must be resolved from it.
    sys.path.insert(0, str(script.parent))
    sys.argv = [str(script)] + list(argv[1:])
    runpy.run_path(str(script), run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
