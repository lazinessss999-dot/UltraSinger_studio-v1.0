"""UltraSinger Studio — Web backend.

Wraps the UltraSinger CLI pipeline in a small FastAPI service:
  * upload an audio file (or give a YouTube URL)
  * pick options / presets
  * watch the live processing log
  * download the generated UltraStar.txt / MIDI / audio

The pipeline itself runs as a subprocess, so a crash inside the AI stack
never takes the web server down, and the environment (Python 3.12 + pinned
deps + ffmpeg) is exactly the one the image was built with.
"""

import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from fastapi import Body, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse

BASE_DIR = Path(os.environ.get("US_STUDIO_HOME", Path(__file__).resolve().parent.parent))
SRC_DIR = BASE_DIR / "UltraSinger-src" / "src"
DATA_DIR = Path(os.environ.get("US_DATA_DIR", BASE_DIR / "data"))
JOBS_DIR = DATA_DIR / "jobs"
MODELS_DIR = DATA_DIR / "models"
STATIC_DIR = Path(__file__).resolve().parent / "static"
LYRICS_DIR = DATA_DIR / "lyrics"
LYRICS_CACHE_DIR = LYRICS_DIR / "cache"
LYRICS_CACHE_TTL = 30 * 24 * 3600
sys.path.insert(0, str(Path(__file__).resolve().parent))
PYTHON = os.environ.get("US_PIPELINE_PYTHON", sys.executable)
IS_WINDOWS = os.name == "nt"

# HuggingFace mirror for slow/blocked networks (created by use_hf_mirror.bat).
HF_MIRROR_URL = "https://hf-mirror.com"
HF_DIRECT_URL = "https://huggingface.co"
HF_MIRROR_FLAG = Path(os.environ.get("US_HF_MIRROR_FLAG", BASE_DIR / "hf_mirror.on"))
HF_ENDPOINT_CACHE = MODELS_DIR / ".hf_endpoint.json"
HF_ENDPOINT_TTL = 3600
WHISPER_GPU_CACHE = MODELS_DIR / ".whisper_gpu.json"
WHISPER_GPU_TTL = 24 * 3600
AUDIO_STACK_CACHE = MODELS_DIR / ".audio_stack.json"
AUDIO_STACK_TTL = 24 * 3600

#: torchcodec is a compiled extension: the wheel must be built against the
#: exact torch version (official compatibility table). A mismatch produces the
#: Windows dialog "entry point not found: torch_get_const_data_ptr in
#: libtorchcodec_image.dll" - the pipeline then dies with an ImportError.
#: whisperx -> pyannote-audio requires torchcodec>=0.7.0 without an upper
#: bound, so an unguarded install picks a too new build.
TORCHCODEC_FOR_TORCH = {
    "2.8": "0.7.0",
    "2.9": "0.8.1",
    "2.10": "0.10.0",
    "2.11": "0.16.0",
}
DEFAULT_TORCHCODEC = "0.7.0"

#: Windows error dialogs ("entry point not found", "DLL not found") must never
#: block a background process: tell the loader to fail quietly instead.
#: SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX
NO_DIALOG_BOOTSTRAP = (
    "import ctypes,os\n"
    "if os.name=='nt':\n"
    "    ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)\n"
)


#: Quantized demucs models (mdx_q, mdx_extra_q) need the `diffq` package.
#: diffq is source-only for Python 3.11+ (newest Windows wheel is cp310), so it
#: cannot be installed without Visual C++ Build Tools. Those presets are
#: therefore switched to the plain model instead of failing mid-run.
DIFFQ_FALLBACK = {"mdx_q": "mdx", "mdx_extra_q": "mdx_extra"}
DIFFQ_CACHE = MODELS_DIR / ".diffq.json"
DIFFQ_TTL = 7 * 24 * 3600

#: Which compute types the actual hardware supports (ctranslate2 knows: FP16
#: needs compute capability >= 7.0, so Pascal cards like the GTX 1070 (6.1)
#: can only do int8/float32 - asking for float16 there fails with
#: "Requested float16 compute type, but the target device or backend do not
#: support efficient float16 computation").
COMPUTE_CACHE = MODELS_DIR / ".compute_types.json"
COMPUTE_TTL = 7 * 24 * 3600
COMPUTE_PREFERENCE = {
    "cuda": ["float16", "int8_float16", "int8_float32", "float32"],
    "cpu": ["int8", "int8_float32", "float32"],
}
_COMPUTE_PROBE = (
    NO_DIALOG_BOOTSTRAP +
    "import json\n"
    "out={}\n"
    "try:\n"
    "    import ctranslate2\n"
    "    for dev in ('cuda','cpu'):\n"
    "        try:\n"
    "            out[dev]=sorted(ctranslate2.get_supported_compute_types(dev, 0))\n"
    "        except Exception:\n"
    "            out[dev]=[]\n"
    "except Exception as error:\n"
    "    out={'cuda':[],'cpu':[],'error':type(error).__name__}\n"
    "print('RESULT'+json.dumps(out))\n"
)

_AUDIO_STACK_PROBE = (
    NO_DIALOG_BOOTSTRAP +
    "import json\n"
    "import importlib.metadata as md\n"
    "out={'torch':None,'torchcodec':None,'ok':False,'error':None}\n"
    "def ver(name):\n"
    "    try:\n"
    "        return md.version(name)\n"
    "    except Exception:\n"
    "        return None\n"
    "out['torch']=ver('torch')\n"
    "out['torchcodec']=ver('torchcodec')\n"
    "try:\n"
    "    import torch\n"
    "    import torchcodec\n"
    "    from torchcodec.decoders import AudioDecoder\n"
    "    import torchaudio\n"
    "    out['ok']=True\n"
    "except BaseException as error:\n"
    "    out['error']=type(error).__name__+': '+str(error)[:300]\n"
    "print('RESULT'+json.dumps(out))\n"
)


def torchcodec_mismatch(torch_version: Optional[str], torchcodec_version: Optional[str]) -> bool:
    """True when the installed torchcodec is not built for this torch."""
    if not torch_version or not torchcodec_version:
        return False
    expected = expected_torchcodec(torch_version)
    return torchcodec_version.split("+")[0] != expected

def _probe_hf_endpoint(url: str, timeout: float = 6.0) -> bool:
    """True when `url` answers like a real HuggingFace endpoint."""
    try:
        request = urllib.request.Request(
            f"{url}/api/models/Systran/faster-whisper-base",
            headers={"User-Agent": "ultrasinger-studio"},
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read(4096).decode("utf-8", "replace")
        return response.status == 200 and '"id"' in body
    except Exception:
        return False


def hf_endpoint(force_probe: bool = False) -> str:
    """Pick a HuggingFace endpoint that actually answers.

    Direct access to huggingface.co is unreliable on some networks (the
    download dies with "Read timed out" or a response that is not from
    HuggingFace at all). Then the hf-mirror.com copy is used instead.
    """
    if HF_MIRROR_FLAG.exists():
        return HF_MIRROR_URL
    cached = {}
    try:
        cached = json.loads(HF_ENDPOINT_CACHE.read_text(encoding="utf-8"))
    except Exception:
        cached = {}
    if (not force_probe and cached.get("url")
            and time.time() - cached.get("ts", 0) < HF_ENDPOINT_TTL):
        return cached["url"]
    endpoint = HF_DIRECT_URL
    if not _probe_hf_endpoint(HF_DIRECT_URL):
        if _probe_hf_endpoint(HF_MIRROR_URL):
            endpoint = HF_MIRROR_URL
    try:
        HF_ENDPOINT_CACHE.write_text(
            json.dumps({"url": endpoint, "ts": time.time()}), encoding="utf-8")
    except Exception:
        pass
    return endpoint


def _read_cache(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def expected_torchcodec(torch_version: str) -> str:
    """Return the torchcodec build that matches the given torch version."""
    parts = torch_version.split("+")[0].split(".")
    key = ".".join(parts[:2])
    return TORCHCODEC_FOR_TORCH.get(key, DEFAULT_TORCHCODEC)


def uv_launcher() -> Optional[list[str]]:
    local = BASE_DIR / "tools" / "uv" / ("uv.exe" if IS_WINDOWS else "uv")
    if local.is_file():
        return [str(local)]
    found = shutil.which("uv")
    return [found] if found else None


def _uv_pip(args: list[str], env: dict, timeout: int = 1800) -> tuple[int, str]:
    launcher = uv_launcher()
    if launcher is None:
        return 1, "uv is not available"
    cmd = launcher + ["pip", "install", "-p", PYTHON] + args
    try:
        result = subprocess.run(cmd, capture_output=True, env=env, timeout=timeout,
                                cwd=str(BASE_DIR))
    except Exception as error:
        return 1, str(error)
    output = (result.stdout + result.stderr).decode("utf-8", "replace")
    return result.returncode, output


def compute_types(env: dict, force_probe: bool = False) -> dict:
    """Ask ctranslate2 which compute types this machine really supports."""
    cached = _read_cache(COMPUTE_CACHE)
    if (not force_probe and cached.get("cuda") is not None
            and "ts" in cached and time.time() - cached.get("ts", 0) < COMPUTE_TTL):
        return cached
    info = {"cuda": [], "cpu": []}
    try:
        result = subprocess.run([PYTHON, "-c", _COMPUTE_PROBE], capture_output=True,
                                env=env, timeout=180, cwd=str(BASE_DIR))
        for line in result.stdout.decode("utf-8", "replace").splitlines():
            if line.startswith("RESULT"):
                info.update(json.loads(line[len("RESULT"):]))
                break
    except Exception:
        pass
    info["ts"] = time.time()
    try:
        COMPUTE_CACHE.write_text(json.dumps(info), encoding="utf-8")
    except Exception:
        pass
    return info


def best_compute_type(supported: list, target: str) -> Optional[str]:
    """Pick the fastest compute type that is supported on this device."""
    for candidate in COMPUTE_PREFERENCE.get(target, []):
        if candidate in (supported or []):
            return candidate
    return None


def diffq_available(env: dict, force_probe: bool = False) -> bool:
    """Is the diffq package importable (needed by quantized demucs models)?"""
    cached = _read_cache(DIFFQ_CACHE)
    if (not force_probe and "ok" in cached
            and time.time() - cached.get("ts", 0) < DIFFQ_TTL):
        return bool(cached["ok"])
    try:
        result = subprocess.run([PYTHON, "-c", "import diffq"], capture_output=True,
                                env=env, timeout=120, cwd=str(BASE_DIR))
        ok = result.returncode == 0
    except Exception:
        ok = False
    try:
        DIFFQ_CACHE.write_text(json.dumps({"ok": ok, "ts": time.time()}), encoding="utf-8")
    except Exception:
        pass
    return ok


def audio_stack_probe(env: dict, force_probe: bool = False) -> dict:
    """Check torchcodec/torchaudio in a dialog-free subprocess."""
    cached = {}
    try:
        cached = json.loads(AUDIO_STACK_CACHE.read_text(encoding="utf-8"))
    except Exception:
        cached = {}
    if (not force_probe and "ok" in cached
            and time.time() - cached.get("ts", 0) < AUDIO_STACK_TTL):
        return cached

    info: dict = {"ok": False, "torch": None, "torchcodec": None, "error": None}
    try:
        result = subprocess.run([PYTHON, "-c", _AUDIO_STACK_PROBE],
                                capture_output=True, env=env, timeout=300,
                                cwd=str(BASE_DIR))
        for line in result.stdout.decode("utf-8", "replace").splitlines():
            if line.startswith("RESULT"):
                info.update(json.loads(line[len("RESULT"):]))
                break
        else:
            info["error"] = "probe produced no result"
    except Exception as error:
        info["error"] = f"{type(error).__name__}: {error}"
    info["mismatch"] = torchcodec_mismatch(info.get("torch"), info.get("torchcodec"))
    info["ts"] = time.time()
    try:
        AUDIO_STACK_CACHE.write_text(json.dumps(info), encoding="utf-8")
    except Exception:
        pass
    return info


def audio_stack_repair(env: dict, info: dict, log) -> dict:
    """Install the torchcodec build that matches the installed torch."""
    torch_version = info.get("torch") or ""
    target = expected_torchcodec(torch_version) if torch_version else DEFAULT_TORCHCODEC
    log(f"[i] Несовместимая библиотека torchcodec "
        f"({info.get('torchcodec') or '?'}) для torch {torch_version or '?'}. "
        f"Ставлю torchcodec {target} (это ~2 МБ, ничего больше не качается).")
    code, output = _uv_pip(["--reinstall", f"torchcodec=={target}"], env)
    tail = "\n".join(output.strip().splitlines()[-6:])
    if code != 0:
        log(f"[i] Не удалось поставить torchcodec {target}: {tail}")
        return info
    log(f"[i] torchcodec {target}: установлен.")
    return audio_stack_probe(env, force_probe=True)


def whisper_gpu_ok(env: dict, force_probe: bool = False) -> bool:
    """Check whether faster-whisper (ctranslate2) can really use the GPU.

    On Windows ctranslate2 needs CUDA/cuDNN DLLs whose versions must match
    the ones torch ships. A mismatch shows up as a Windows popup
    ("entry point not found in the DLL") or as a hard crash, so the check
    runs CTranslate2 in a separate process with error dialogs suppressed.
    If it fails, Whisper is switched to the CPU automatically.
    """
    cached = {}
    try:
        cached = json.loads(WHISPER_GPU_CACHE.read_text(encoding="utf-8"))
    except Exception:
        cached = {}
    if (not force_probe and "ok" in cached
            and time.time() - cached.get("ts", 0) < WHISPER_GPU_TTL):
        return bool(cached["ok"])

    code = (
        NO_DIALOG_BOOTSTRAP +
        "import json,torch,ctranslate2\n"
        "types=sorted(ctranslate2.get_supported_compute_types('cuda'))\n"
        "print('RESULT'+json.dumps(bool(types)))\n"
    )
    ok = False
    try:
        result = subprocess.run(
            [PYTHON, "-c", code], capture_output=True, env=env,
            timeout=180, cwd=str(BASE_DIR))
        for line in result.stdout.decode("utf-8", "replace").splitlines():
            if line.startswith("RESULT"):
                ok = json.loads(line[len("RESULT"):])
                break
    except Exception:
        ok = False
    try:
        WHISPER_GPU_CACHE.write_text(
            json.dumps({"ok": ok, "ts": time.time()}), encoding="utf-8")
    except Exception:
        pass
    return ok


JOBS_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

# Stages shown in the UI, in pipeline order.
STAGES = [
    ("input", "Input / metadata"),
    ("separation", "Vocal separation (demucs)"),
    ("prep", "Audio cleanup (denoise, mono)"),
    ("analysis", "BPM and key"),
    ("transcription", "Lyrics (Whisper)"),
    ("pitch", "Pitch (SwiftF0)"),
    ("output", "Export"),
]

STAGE_MARKERS = [
    ("separation", ("Separating vocals",)),
    ("prep", ("Reduce noise", "Converting audio", "Muting", "silence")),
    ("analysis", ("BPM is", "Detecting musical key", "Detected key")),
    ("transcription", ("Transcribing", "whisper", "alignment model", "Transcribed")),
    ("pitch", ("Pitching with", "SwiftF0")),
    ("output", ("Creating Ultrastar", "Creating midi", "Creating UltraStar", "score", "Export Ultrastar")),
]


def pipeline_env(probe_hf: bool = False) -> dict:
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["HF_HOME"] = str(MODELS_DIR / "hf")
    env["TORCH_HOME"] = str(MODELS_DIR / "torch")
    env["XDG_CACHE_HOME"] = str(MODELS_DIR)
    env["NLTK_DATA"] = str(MODELS_DIR / "nltk")
    env["PYTHONWARNINGS"] = "ignore"
    # Large model downloads over slow links: allow a longer read timeout.
    env.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "90")
    env.setdefault("HF_HUB_ETAG_TIMEOUT", "90")
    if HF_MIRROR_FLAG.exists():
        env["HF_ENDPOINT"] = HF_MIRROR_URL
    elif probe_hf:
        env["HF_ENDPOINT"] = hf_endpoint()
    # CUDA DLLs that ship with torch / nvidia wheels must be findable by
    # other native libraries too (ctranslate2 looks for cublas / cudnn).
    dll_dirs = []
    candidate = Path(env.get("US_PIPELINE_PYTHON", PYTHON)).parent
    for site_packages in (candidate.parent / "Lib" / "site-packages",
                          candidate.parent / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"):
        if not site_packages.is_dir():
            continue
        dll_dirs.append(site_packages / "torch" / "lib")
        nvidia = site_packages / "nvidia"
        if nvidia.is_dir():
            dll_dirs += [p for p in nvidia.glob("*/bin") if p.is_dir()]
    existing = [str(p) for p in dll_dirs if p.is_dir()]
    if existing:
        env["PATH"] = os.pathsep.join(existing + [env.get("PATH", "")])
    return env


#: Which HuggingFace repositories a run needs, so they can be fetched before
#: the pipeline starts (huggingface.co is unreachable on some networks).
WHISPER_REPOS = {
    "tiny": "Systran/faster-whisper-tiny",
    "base": "Systran/faster-whisper-base",
    "small": "Systran/faster-whisper-small",
    "medium": "Systran/faster-whisper-medium",
    "large-v1": "Systran/faster-whisper-large-v3",
    "large-v2": "Systran/faster-whisper-large-v2",
    "large-v3": "Systran/faster-whisper-large-v3",
    "large": "Systran/faster-whisper-large-v3",
    "distil-large-v3": "Systran/faster-distil-whisper-large-v3",
}
WHISPER_ALIASES = {"large": "large-v3", "large-v1": "large-v3"}


def resolve_whisper_model(name: str) -> str:
    """large-v1 is the original large: same ~3 GB as v3, worse accuracy."""
    return WHISPER_ALIASES.get(str(name or "small").strip(), str(name or "small").strip())


def _load_prefetch_sets() -> dict:
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from prefetch_models import ALIGN_LANGUAGES, REPOS

        sets = dict(REPOS)
        sets.update({f"align-{lang}": repo for lang, repo in ALIGN_LANGUAGES.items()})
        return sets
    except Exception:
        return {}


PREFETCH_SETS = _load_prefetch_sets()


def needed_repos(options: dict) -> list[str]:
    """Repositories this job will read, in the order the pipeline needs them."""
    repos: list[str] = []
    if not options.get("lyrics_word_synced"):
        whisper_repo = WHISPER_REPOS.get(str(options.get("whisper_model", "small")))
        if whisper_repo:
            repos.append(whisper_repo)
    if options.get("whisper_align_model"):
        repos.append(str(options["whisper_align_model"]))
    elif options.get("language") and options["language"] != "auto":
        align_repo = PREFETCH_SETS.get(f"align-{options['language']}")
        if align_repo:
            repos.append(align_repo)
    return repos


def repo_cached(repo: str, env: Optional[dict] = None) -> bool:
    home = Path((env or {}).get("HF_HOME") or (MODELS_DIR / "hf"))
    root = home / "hub" / ("models--" + repo.replace("/", "--"))
    if not root.is_dir():
        return False
    for snapshot in (root / "snapshots").glob("*"):
        if snapshot.is_dir() and len([p for p in snapshot.rglob("*") if p.is_file()]) >= 3:
            return True
    return False


def ensure_models(repos: list[str], env: dict, log) -> None:
    """Download missing models before the pipeline starts."""
    missing = [r for r in repos if not repo_cached(r, env)]
    if not missing:
        log(f"Модели на месте: {len(repos)} шт. в локальном кэше.")
        return
    sets = [name for name, repo in PREFETCH_SETS.items() if repo in missing]
    if not sets:
        log(f"Нет в кэше: {', '.join(missing)} - скачаю при обработке.")
        return
    log(f"Догружаю модели перед запуском: {', '.join(sets)} "
        f"(это займёт время, качается один раз)")
    script = str(Path(__file__).resolve().parent / "prefetch_models.py")
    try:
        proc = subprocess.Popen([PYTHON, script] + sets, cwd=str(BASE_DIR), env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for raw in iter(proc.stdout.readline, b""):
            log("  " + raw.decode("utf-8", "replace").rstrip())
        proc.wait()
    except Exception as error:
        log(f"Не удалось догрузить модели: {type(error).__name__}: {error}")
        return
    left = [r for r in missing if not repo_cached(r, env)]
    if left:
        log(f"Внимание: не скачалось - {', '.join(left)}. "
            f"Проверьте интернет и повторите, скачанное сохраняется.")
    else:
        log("Модели догружены.")


@dataclass
class Job:
    id: str
    name: str
    status: str = "queued"  # queued | running | done | error | cancelled
    input_source: str = ""  # "file:<name>" or "youtube:<url>"
    input_path: str = ""
    out_dir: str = ""
    options: dict = field(default_factory=dict)
    log: list = field(default_factory=list)
    stage: str = "input"
    error: Optional[str] = None
    files: list = field(default_factory=list)
    created: float = field(default_factory=time.time)
    finished: Optional[float] = None
    process: Optional[subprocess.Popen] = None
    log_lock: threading.Lock = field(default_factory=threading.Lock)

    def add_log(self, line: str) -> None:
        clean = ANSI_RE.sub("", line).rstrip()
        with self.log_lock:
            self.log.append(clean)
            if len(self.log) > 8000:
                self.log = self.log[-6000:]
        self._advance_stage(clean)

    def _advance_stage(self, line: str) -> None:
        order = [s[0] for s in STAGES]
        markers_by_key = dict(STAGE_MARKERS)
        lower = line.lower()
        for idx, key in enumerate(order):
            markers = markers_by_key.get(key, ())
            if any(m.lower() in lower for m in markers):
                if order.index(self.stage) < idx:
                    self.stage = key
                break

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "status": self.status,
            "input_source": self.input_source,
            "stage": self.stage,
            "error": self.error,
            "files": self.files,
            "lyrics_source": (self.options or {}).get("lyrics_source", ""),
            "created": self.created,
            "finished": self.finished,
        }


JOBS: dict[str, Job] = {}
JOBS_LOCK = threading.Lock()
WORKER_BUSY = threading.Lock()  # only one pipeline job at a time

SERVER_INFO: dict = {}


def detect_server_info() -> dict:
    info = {"device": "cpu", "gpu": None, "vram_gb": None, "ffmpeg": False, "python": PYTHON}
    info["ffmpeg"] = shutil.which("ffmpeg") is not None
    try:
        code = (
            "import torch,json;"
            "ok=torch.cuda.is_available();"
            "print(json.dumps({'ok':ok,'name':torch.cuda.get_device_name(0) if ok else None,"
            "'vram':round(torch.cuda.get_device_properties(0).total_memory/1024**3,1) if ok else None}))"
        )
        r = subprocess.run([PYTHON, "-c", code], capture_output=True, env=pipeline_env(), timeout=120)
        out = r.stdout.decode("utf-8", "replace").strip().splitlines()[-1]
        d = json.loads(out)
        if d["ok"]:
            info["device"] = "cuda"
            info["gpu"] = d["name"]
            info["vram_gb"] = d["vram"]
    except Exception:
        pass
    return info


def build_cmd(job: Job) -> tuple[list[str], list[str]]:
    """Build the pipeline command. Returns (args, notes for the log)."""
    o = job.options
    notes: list[str] = []
    env = pipeline_env()
    whisper_gpu = o.get("whisper_gpu", True)
    if whisper_gpu and whisper_gpu_ok(env) is False:
        whisper_gpu = False
        notes.append(
            "Whisper переключён на CPU: GPU-режим Whisper (ctranslate2) не работает "
            "в этом окружении — на Windows это обычно несовпадение CUDA-библиотек, "
            "которое даёт системное окно про точку входа в DLL. "
            "Разделение голоса (demucs) и определитель тона продолжают работать на видеокарте.")
    launcher = str(Path(__file__).resolve().parent / "pipeline_launcher.py")
    args = [PYTHON, launcher, str(SRC_DIR / "UltraSinger.py"),
            "-i", job.input_path, "-o", job.out_dir]
    whisper_model = resolve_whisper_model(o.get("whisper_model", "small"))
    if whisper_model != str(o.get("whisper_model") or "").strip():
        notes.append(
            f"Модель Whisper «{o.get('whisper_model')}» устарела и не легче large-v3 "
            f"(оба ~3 ГБ). Беру large-v3 — она точнее. Если нужна легче: medium или пресет «Баланс».")
        o["whisper_model"] = whisper_model
    args += ["--whisper", whisper_model]
    if o.get("whisper_batch_size"):
        args += ["--whisper_batch_size", str(o["whisper_batch_size"])]
    whisper_target = "cpu" if (o.get("force_cpu") or o.get("force_whisper_cpu")
                               or not whisper_gpu) else "cuda"
    supported_types = compute_types(env).get(whisper_target) or []
    compute_type = str(o.get("whisper_compute_type") or "").strip()
    if compute_type in ("", "auto", "default"):
        compute_type = (best_compute_type(supported_types, whisper_target)
                        or ("int8" if whisper_target == "cpu" else "float16"))
        notes.append(
            f"Тип вычислений Whisper выбран автоматически: {compute_type}"
            + (f" (доступно на этом устройстве: {', '.join(supported_types)})"
               if supported_types else " (список возможностей устройства недоступен)"))
    elif supported_types and compute_type not in supported_types:
        fallback = best_compute_type(supported_types, whisper_target) or "float32"
        notes.append(
            f"Тип вычислений {compute_type} не поддерживается этим устройством "
            f"(доступно: {', '.join(supported_types)}) — использую {fallback}. "
            f"Обычно так бывает с float16 на картах до GeForce 20xx (у GTX 10xx нет "
            f"аппаратного fp16) — на скорость это влияет слабо.")
        compute_type = fallback
    if compute_type:
        args += ["--whisper_compute_type", compute_type]
    if o.get("language") and o["language"] != "auto":
        args += ["--language", o["language"]]
    if o.get("whisper_align_model"):
        args += ["--whisper_align_model", o["whisper_align_model"]]
    lyrics_path = o.get("lyrics_path")
    if lyrics_path and Path(str(lyrics_path)).is_file():
        args += ["--lyrics_file", str(lyrics_path)]
    artist = (o.get("lyrics_artist") or "").strip()
    title = (o.get("lyrics_title") or "").strip()
    if not artist or not title:
        try:
            guess = lyrics_module().guess_artist_title(job.input_path)
            artist = artist or (guess.get("artist") or "").strip()
            title = title or (guess.get("title") or "").strip()
        except Exception:
            pass
    if artist:
        args += ["--artist", artist]
    if title:
        args += ["--title", title]
    if o.get("demucs") == "off":
        args += ["--disable_separation"]
    elif o.get("demucs"):
        demucs_model = str(o["demucs"])
        if demucs_model in DIFFQ_FALLBACK and not diffq_available(env):
            plain = DIFFQ_FALLBACK[demucs_model]
            notes.append(
                f"Модель разделения {demucs_model} квантованная и требует пакета diffq, "
                f"который не собирается на Windows (нужен Visual C++ Build Tools). "
                f"Использую {plain} — та же модель без квантования.")
            demucs_model = plain
        args += ["--demucs", demucs_model]
    if o.get("hyphenation") is False:
        args += ["--disable_hyphenation"]
    if o.get("karaoke") is False:
        args += ["--disable_karaoke"]
    if o.get("quantize_to_key") is False:
        args += ["--no_quantize_to_key"]
    else:
        args += ["--quantize_to_key"]
    args += ["--format_version", o.get("format_version", "1.2.0")]
    if o.get("create_audio_chunks"):
        args += ["--create_audio_chunks"]
    if o.get("keep_cache"):
        args += ["--keep_cache"]
    if o.get("plot"):
        args += ["--plot"]
    if o.get("keep_numbers"):
        args += ["--keep_numbers"]
    if o.get("force_cpu"):
        args += ["--force_cpu"]
    if o.get("force_whisper_cpu") or not whisper_gpu:
        args += ["--force_whisper_cpu"]
    if o.get("cookiefile"):
        args += ["--cookiefile", o["cookiefile"]]
    if o.get("ffmpeg_path"):
        args += ["--ffmpeg", o["ffmpeg_path"]]
    return args, notes


def lyrics_module():
    """Lazy import: the finder works even without the audio stack."""
    import lyrics_finder  # noqa: PLC0415 - cheap, avoids import cycles at boot
    return lyrics_finder


def _lyrics_cache_key(input_path: str, mode: str) -> Path:
    try:
        stamp = int(os.path.getmtime(input_path))
    except OSError:
        stamp = 0
    name = hashlib.sha1(f"{input_path}|{stamp}|{mode}".encode("utf-8")).hexdigest()[:16]
    return LYRICS_CACHE_DIR / f"{name}.json"


def _apply_lyrics_language(options: dict, text: str, log) -> None:
    """Use the lyrics script as a hint when the language is set to auto."""
    language = str(options.get("language") or "auto").strip().lower()
    if language not in ("", "auto"):
        return
    try:
        detected = lyrics_module()._lyrics_module().detect_language(text)
    except Exception:
        return
    if detected:
        options["language"] = detected
        log(f"[i] Язык определён по тексту песни: {detected} — "
            f"модель выравнивания возьмётся под него.")


def _mark_word_synced(options: dict, text: str, log) -> None:
    """Remember that the lyrics carry per word timings: whisper is not needed."""
    try:
        finder = lyrics_module()
        parsed = finder._lyrics_module().parse_lyrics_text(text)
        lines_total = max(1, len(parsed["lines"]))
        if parsed["timed_words"] and len(parsed["timed_words"]) >= 0.8 * lines_total:
            options["lyrics_word_synced"] = True
            log("[i] В тексте есть пословные тайминги: Whisper-модель для этой песни не нужна "
                "(не качаю её зря).")
    except Exception:
        pass


def resolve_lyrics(job: Job, log) -> Optional[str]:
    """Put the lyrics for this job into a file and return its path.

    Order follows the settings: user text > internet > file tags / sidecar.
    Never raises: a failed search only means whisper transcribes by itself.
    """
    options = job.options or {}
    mode = str(options.get("lyrics_mode") or "auto").strip().lower()
    manual = (options.get("lyrics_text") or "").strip()

    LYRICS_DIR.mkdir(parents=True, exist_ok=True)
    LYRICS_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        finder = lyrics_module()
    except Exception as error:  # noqa: BLE001
        log(f"[i] Модуль поиска текста недоступен ({error}) — продолжаю без него.")
        return None

    if manual:
        parsed = finder._lyrics_module().parse_lyrics_text(manual)
        extension = ".lrc" if parsed["is_lrc"] else ".txt"
        path = LYRICS_DIR / f"{job.id}{extension}"
        finder._lyrics_module().write_lyrics_file(str(path), manual)
        options["lyrics_path"] = str(path)
        options["lyrics_source"] = "текст из интерфейса"
        log(f"Текст песни: беру ваш текст ({len(parsed['lines'])} строк"
            f"{', с таймингами' if parsed['is_lrc'] else ''}) — слова будут из него, "
            f"нейросеть подставит только время.")
        _mark_word_synced(options, manual, log)
        _apply_lyrics_language(options, manual, log)
        return str(path)

    if mode == "off":
        log("Текст песни: поиск выключен, слова расшифрует Whisper.")
        return None

    order = {"auto": ("online", "file"), "online": ("online",), "file": ("file",)}.get(
        mode, ("online", "file")
    )
    artist = (options.get("lyrics_artist") or "").strip()
    title = (options.get("lyrics_title") or "").strip()

    cache_file = _lyrics_cache_key(job.input_path, mode)
    result = None
    try:
        if cache_file.is_file():
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            if time.time() - float(cached.get("ts", 0)) < LYRICS_CACHE_TTL:
                result = cached.get("result")
                if result:
                    log(f"Текст песни: найден ранее в «{result.get('source')}» — беру его.")
    except Exception:
        result = None

    if result is None:
        try:
            result = finder.find_lyrics(job.input_path, artist=artist, title=title, order=order)
        except Exception as error:  # noqa: BLE001
            log(f"[i] Поиск текста не удался ({str(error)[:120]}) — продолжаю без него.")
            return None
        try:
            cache_file.write_text(
                json.dumps({"ts": time.time(), "result": result}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass

    if not result:
        log("[i] Текст песни не найден ни в сети, ни в тегах файла — слова расшифрует "
            "Whisper. Можно вставить текст вручную в поле «Текст песни».")
        return None

    text = result.get("text") or ""
    extension = ".lrc" if result.get("synced") else ".txt"
    path = LYRICS_DIR / f"{job.id}{extension}"
    finder._lyrics_module().write_lyrics_file(str(path), text)
    options["lyrics_path"] = str(path)
    options["lyrics_source"] = result.get("source") or "интернет"
    lines = len([line for line in text.splitlines() if line.strip()])
    log(f"Текст песни: найден в «{result.get('source')}» — {lines} строк"
        f"{' (с таймингами, Whisper не нужен)' if result.get('synced') else ''}. "
        f"Слова берутся из файла, нейросеть выравнивает их по звуку.")
    if result.get("artist") or result.get("title"):
        log(f"[i] Совпадение: {result.get('artist', '')} — {result.get('title', '')}".rstrip(" —"))

    _mark_word_synced(options, text, log)
    _apply_lyrics_language(options, text, log)
    return str(path)


def collect_results(job: Job) -> None:
    files = []
    root = Path(job.out_dir)
    if not root.exists():
        return
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(Path(job.out_dir).parent).as_posix()
            size = p.stat().st_size
            if size == 0:
                continue
            files.append({"name": rel, "size": size})
    # keep only the interesting artifacts
    keep_ext = (".txt", ".mid", ".midi", ".wav", ".mp3", ".png", ".jpg", ".sheetmusic", ".mscz")
    files = [f for f in files if f["name"].lower().endswith(keep_ext)]
    job.files = files


def run_job(job: Job) -> None:
    job.add_log("Проверка окружения и загрузка моделей...")
    env = pipeline_env(probe_hf=True)
    endpoint = env.get("HF_ENDPOINT", "https://huggingface.co")
    job.add_log(f"Источник моделей: {endpoint}")

    try:
        resolve_lyrics(job, job.add_log)
    except Exception as error:  # noqa: BLE001 - lyrics must never break a run
        job.add_log(f"[i] Текст песни: непредвиденная ошибка ({str(error)[:120]}) — продолжаю без него.")

    requested = str((job.options or {}).get("whisper_model") or "small")
    resolved = resolve_whisper_model(requested)
    if resolved != requested:
        job.add_log(
            f"[i] Модель Whisper «{requested}» — это не облегчённая версия, "
            f"а первый large (~3 ГБ, как v3, но хуже). Беру large-v3. "
            f"Легче large: medium (~1.5 ГБ) или пресет «Баланс» (small)."
        )
        job.options["whisper_model"] = resolved

    repos = needed_repos(job.options)
    ensure_models(repos, env, job.add_log)
    still_missing = [r for r in repos if not repo_cached(r, env)]
    if still_missing:
        job.status = "error"
        job.error = "Не удалось скачать модели: " + ", ".join(still_missing)
        job.add_log(
            "=== ОШИБКА: модель не скачалась до конца. "
            "Повторите запуск — докачается с того же места. "
            "Либо выберите пресет «Баланс» (модель small уже есть). ==="
        )
        job.finished = time.time()
        return

    hub_works = _probe_hf_endpoint(endpoint, timeout=8)
    if not hub_works and repos and all(repo_cached(r, env) for r in repos):
        # Everything is local: do not let the pipeline wait for a dead Hub.
        env["HF_HUB_OFFLINE"] = "1"
        job.add_log("HuggingFace недоступен, работаю на локальных моделях "
                    "(никаких сетевых попыток).")

    stack = audio_stack_probe(env)
    if stack.get("ok"):
        pass  # versions match and import works — nothing to tell the user
    elif stack.get("mismatch"):
        # torchcodec is built for another torch: on Windows this is what pops
        # up "entry point not found". Install the matching build.
        stack = audio_stack_repair(env, stack, job.add_log)
        if not stack.get("ok"):
            job.add_log("[i] torchcodec не обязателен для этого пайплайна — продолжаю.")
    # else: package versions already match. AudioDecoder still needs FFmpeg
    # DLLs next to libtorchcodec (not the ffmpeg.exe we use). Whisper never
    # goes through torchcodec, so a failed import here is noise — stay quiet.

    cmd, notes = build_cmd(job)
    for note in notes:
        job.add_log(f"[i] {note}")
    shown = list(cmd)
    if len(shown) > 2:
        shown[1] = "UltraSinger.py"
    job.add_log("$ " + " ".join(shown))
    popen_kwargs = dict(
        cwd=str(SRC_DIR),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if IS_WINDOWS:
        popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        popen_kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen(cmd, **popen_kwargs)
        job.process = proc
    except Exception as e:
        job.status = "error"
        job.error = f"Не удалось запустить пайплайн: {e}"
        job.finished = time.time()
        return

    for line in iter(proc.stdout.readline, b""):
        try:
            job.add_log(line.decode("utf-8", "replace"))
        except Exception:
            job.add_log(line.decode("latin-1", "replace"))
    proc.wait()
    job.process = None

    if job.status == "cancelled":
        job.status = "cancelled"
        job.finished = time.time()
        return

    if proc.returncode == 0:
        job.status = "done"
        collect_results(job)
        job.add_log(f"=== Готово. Задача '{job.name}' завершена успешно ===")
    else:
        job.status = "error"
        job.error = f"Пайплайн завершился с кодом {proc.returncode}"
        job.add_log(f"=== ОШИБКА: пайплайн завершился с кодом {proc.returncode} ===")
    job.finished = time.time()


def worker() -> None:
    """Sequential worker: one job at a time (the AI stack is CPU/GPU bound)."""
    while True:
        with JOBS_LOCK:
            job = next((j for j in JOBS.values() if j.status == "queued"), None)
            if job is None:
                return
            job.status = "running"
        try:
            run_job(job)
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            job.status = "error"
            job.error = str(e)
            for tl in tb.splitlines()[-15:]:
                job.add_log(tl)
            job.finished = time.time()


def get_next_job() -> Optional[Job]:
    with JOBS_LOCK:
        job = next((j for j in JOBS.values() if j.status == "queued"), None)
    if job is not None:
        threading.Thread(target=worker, daemon=True).start()
    return job


def cancel_job(job: Job) -> None:
    if job.status == "running" and job.process is not None:
        job.status = "cancelled"
        if IS_WINDOWS:
            # kill the whole process tree (demucs/whisper run in-process)
            try:
                subprocess.run(["taskkill", "/f", "/t", "/pid", str(job.process.pid)],
                               capture_output=True, timeout=15)
            except Exception:
                try:
                    job.process.kill()
                except Exception:
                    pass
            return
        try:
            os.killpg(os.getpgid(job.process.pid), signal.SIGTERM)
        except Exception:
            try:
                job.process.terminate()
            except Exception:
                pass
        time.sleep(2)
        try:
            os.killpg(os.getpgid(job.process.pid), signal.SIGKILL)
        except Exception:
            pass


app = FastAPI(title="UltraSinger Studio")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)


@app.on_event("startup")
def _startup() -> None:
    SERVER_INFO.update(detect_server_info())
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    # restore finished jobs from previous runs (so history survives restarts)
    try:
        for d in sorted(JOBS_DIR.iterdir(), reverse=True):
            meta = d / "job.json"
            if d.is_dir() and meta.exists():
                try:
                    m = json.loads(meta.read_text())
                    j = Job(id=m["id"], name=m["name"], status=m["status"],
                            input_source=m.get("input_source", ""), input_path=m.get("input_path", ""),
                            out_dir=m.get("out_dir", ""), options=m.get("options", {}),
                            error=m.get("error"), files=m.get("files", []),
                            created=m.get("created", 0), finished=m.get("finished"))
                    logf = d / "log.txt"
                    if logf.exists():
                        j.log = logf.read_text(errors="replace").splitlines()[-6000:]
                    JOBS[j.id] = j
                except Exception:
                    pass
    except Exception:
        pass


def save_job_meta(job: Job) -> None:
    try:
        d = Path(job.out_dir).parent if job.out_dir else JOBS_DIR
        d.mkdir(parents=True, exist_ok=True)
        (d / "job.json").write_text(json.dumps(job.to_dict(), ensure_ascii=False, indent=1))
        with job.log_lock:
            (d / "log.txt").write_text("\n".join(job.log), encoding="utf-8")
    except Exception:
        pass


@app.get("/api/status")
def status():
    with JOBS_LOCK:
        jobs = list(JOBS.values())
    return {
        "server": SERVER_INFO,
        "stages": STAGES,
        "running": any(j.status == "running" for j in jobs),
        "queued": sum(1 for j in jobs if j.status == "queued"),
        "hf_mirror": HF_MIRROR_FLAG.exists(),
        "whisper_gpu": WHISPER_GPU_CACHE.exists() and json.loads(
            WHISPER_GPU_CACHE.read_text(encoding="utf-8")).get("ok", True),
        "models_download": MODELS_DL["status"],
        "audio_stack": _read_cache(AUDIO_STACK_CACHE),
    }


@app.get("/api/settings")
def get_settings():
    return {"hf_mirror": HF_MIRROR_FLAG.exists(), "hf_mirror_url": HF_MIRROR_URL}


@app.post("/api/settings/hf-mirror")
async def set_hf_mirror(payload: dict):
    enabled = bool(payload.get("enabled"))
    if enabled:
        HF_MIRROR_FLAG.write_text(
            "HuggingFace mirror enabled. Models are downloaded from "
            f"{HF_MIRROR_URL}\n", encoding="utf-8")
    elif HF_MIRROR_FLAG.exists():
        HF_MIRROR_FLAG.unlink()
    return {"hf_mirror": HF_MIRROR_FLAG.exists()}


MODELS_DL: dict = {"proc": None, "log": [], "status": "idle", "sets": []}
MODELS_DL_LOCK = threading.Lock()


def _append_models_log(line: str) -> None:
    with MODELS_DL_LOCK:
        MODELS_DL["log"].append(line.rstrip("\n"))
        if len(MODELS_DL["log"]) > 4000:
            del MODELS_DL["log"][:1000]


@app.get("/api/models/download")
def models_download_status():
    with MODELS_DL_LOCK:
        return {
            "status": MODELS_DL["status"],
            "sets": MODELS_DL["sets"],
            "log": MODELS_DL["log"][-400:],
        }


@app.post("/api/models/download")
async def models_download_start(payload: Optional[dict] = None):
    payload = payload or {}
    sets = payload.get("sets") or ["whisper-base", "whisper-small", "whisper-medium", "align-ru"]
    with MODELS_DL_LOCK:
        if MODELS_DL["proc"] is not None and MODELS_DL["proc"].poll() is None:
            raise HTTPException(409, "Загрузка моделей уже идёт")
        MODELS_DL.update({"log": [], "status": "running", "sets": sets})

    env = pipeline_env(probe_hf=True)
    env["US_PIPELINE_PYTHON"] = PYTHON
    script = str(Path(__file__).resolve().parent / "prefetch_models.py")
    _append_models_log(f"Источник моделей: {env.get('HF_ENDPOINT', 'https://huggingface.co')}")
    _append_models_log("$ python prefetch_models.py " + " ".join(sets))

    def _run() -> None:
        try:
            proc = subprocess.Popen(
                [PYTHON, script] + list(sets),
                cwd=str(BASE_DIR), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                **(dict(creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
                   if IS_WINDOWS else dict(start_new_session=True)),
            )
        except Exception as error:
            _append_models_log(f"Не удалось запустить загрузку: {error}")
            with MODELS_DL_LOCK:
                MODELS_DL["status"] = "error"
            return
        with MODELS_DL_LOCK:
            MODELS_DL["proc"] = proc
        for raw in iter(proc.stdout.readline, b""):
            _append_models_log(raw.decode("utf-8", "replace"))
        proc.wait()
        with MODELS_DL_LOCK:
            MODELS_DL["status"] = "done" if proc.returncode == 0 else "error"
            MODELS_DL["proc"] = None
        _append_models_log("=== Загрузка моделей завершена ===" if proc.returncode == 0
                           else "=== Загрузка моделей не удалась, повторите ===")

    threading.Thread(target=_run, daemon=True).start()
    return {"status": "running", "sets": sets}


@app.post("/api/models/download/cancel")
async def models_download_cancel():
    with MODELS_DL_LOCK:
        proc = MODELS_DL["proc"]
    if proc is None or proc.poll() is not None:
        return {"status": MODELS_DL["status"]}
    try:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           capture_output=True)
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except Exception:
        proc.kill()
    with MODELS_DL_LOCK:
        MODELS_DL["status"] = "cancelled"
    return {"status": "cancelled"}


@app.get("/api/presets")
def presets():
    cuda = SERVER_INFO.get("device") == "cuda"
    if cuda:
        vram = SERVER_INFO.get("vram_gb") or 0
        if vram >= 8:
            big = {"model": "large-v3", "compute": "auto", "batch": 8, "demucs": "htdemucs"}
        elif vram >= 4:
            big = {"model": "medium", "compute": "auto", "batch": 4, "demucs": "htdemucs"}
        else:
            big = {"model": "small", "compute": "auto", "batch": 4, "demucs": "mdx"}
        balance = {"model": "small", "compute": "auto", "batch": 8, "demucs": "htdemucs"}
        fast = {"model": "base", "compute": "auto", "batch": 16, "demucs": "off"}
    else:
        big = {"model": "medium", "compute": "auto", "batch": 2, "demucs": "htdemucs"}
        balance = {"model": "small", "compute": "auto", "batch": 4, "demucs": "mdx"}
        fast = {"model": "base", "compute": "auto", "batch": 8, "demucs": "off"}
    return {
        "device": SERVER_INFO.get("device"),
        "presets": {
            "fast": {**fast, "title": "⚡ Fast",
                     "desc": "Minimum time. Good for a test run."},
            "balance": {**balance, "title": "🎯 Balance",
                        "desc": "Recommended starting point."},
            "quality": {**big, "title": "💎 Quality",
                        "desc": "Best accuracy. On CPU this can take 15–40 min."},
        },
    }


@app.get("/api/lyrics/guess")
def lyrics_guess(name: str = ""):
    """Artist/title for a chosen file name (used to pre-fill the search box)."""
    try:
        finder = lyrics_module()
        guess = finder.guess_artist_title(os.path.join("/", name or "audio.mp3"))
        return {"ok": True, **guess}
    except Exception as error:  # noqa: BLE001
        return {"ok": False, "error": str(error), "artist": "", "title": "", "query": ""}


@app.post("/api/lyrics/search")
def lyrics_search(payload: dict = Body(default=None)):
    """Search the internet for lyrics; returns candidates for the user to pick."""
    payload = payload or {}
    artist = str(payload.get("artist") or "").strip()
    title = str(payload.get("title") or "").strip()
    if not artist and not title:
        query = str(payload.get("query") or "").strip()
        artist, title = query, ""
    if not artist and not title:
        raise HTTPException(400, "Укажите исполнителя или название песни")
    try:
        finder = lyrics_module()
    except Exception as error:  # noqa: BLE001
        raise HTTPException(500, f"Модуль поиска текста недоступен: {error}")
    result = finder.online_candidates(artist, title, timeout=12)
    candidates = []
    for item in result["candidates"][:12]:
        text = item["text"] or ""
        candidates.append(
            {
                "source": item["source"],
                "artist": item["artist"],
                "title": item["title"],
                "synced": bool(item["synced"]),
                "extra": item.get("extra", ""),
                "lines": len([line for line in text.splitlines() if line.strip()]),
                "preview": "\n".join(text.splitlines()[:8]),
                "text": text[:40000],
            }
        )
    return {"ok": True, "artists": artist, "title": title,
            "candidates": candidates, "errors": result["errors"]}


@app.post("/api/jobs")
async def create_job(
    file: Optional[UploadFile] = File(None),
    youtube: Optional[str] = Form(None),
    options: Optional[str] = Form(None),
):
    opts = json.loads(options) if options else {}
    name = ""
    input_source = ""
    job_id = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
    job_dir = JOBS_DIR / job_id
    input_dir = job_dir / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    out_dir = str(job_dir / "output")

    if file is not None and file.filename:
        safe = re.sub(r"[^\w\- .()\[\]]+", "_", file.filename)[:120].strip() or "audio"
        dest = input_dir / safe
        with open(dest, "wb") as f:
            shutil.copyfileobj(file.file, f)
        name = Path(safe).stem
        input_source = f"file:{safe}"
    elif youtube and youtube.strip():
        url = youtube.strip()
        if not url.startswith("http"):
            raise HTTPException(400, "Некорректная ссылка на YouTube")
        name = url
        input_source = f"youtube:{url}"
    else:
        raise HTTPException(400, "Нужен файл или ссылка на YouTube")

    if input_source.startswith("file:"):
        input_path = str(input_dir / input_source.split(":", 1)[1])
    else:
        input_path = input_source.split(":", 1)[1]
    job = Job(
        id=job_id, name=name[:100], input_source=input_source,
        input_path=input_path,
        out_dir=out_dir, options=opts,
    )
    with JOBS_LOCK:
        JOBS[job_id] = job
    get_next_job()
    return job.to_dict()


@app.get("/api/jobs")
def list_jobs():
    with JOBS_LOCK:
        jobs = sorted(JOBS.values(), key=lambda j: j.created, reverse=True)
    return [j.to_dict() for j in jobs][:50]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "Задача не найдена")
    d = job.to_dict()
    with job.log_lock:
        d["log"] = list(job.log)
    return d


@app.get("/api/jobs/{job_id}/events")
def job_events(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "Задача не найдена")

    def gen():
        sent = 0
        with job.log_lock:
            sent = len(job.log)
        while True:
            with job.log_lock:
                log = list(job.log)
            if sent < len(log):
                for line in log[sent:]:
                    yield f"data: {json.dumps({'log': line}, ensure_ascii=False)}\n\n"
                sent = len(log)
            d = job.to_dict()
            yield f"data: {json.dumps({'status': d['status'], 'stage': d['stage'], 'error': d['error'], 'files': d['files']}, ensure_ascii=False)}\n\n"
            if job.status in ("done", "error", "cancelled"):
                break
            time.sleep(0.6)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/jobs/{job_id}/cancel")
def cancel(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "Задача не найдена")
    if job.status not in ("running", "queued"):
        raise HTTPException(400, "Задача не активна")
    threading.Thread(target=cancel_job, args=(job,), daemon=True).start()
    return {"ok": True}


@app.get("/api/jobs/{job_id}/download")
def download_zip(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "Задача не найдена")
    out = Path(job.out_dir)
    if not out.exists() or not any(out.iterdir()):
        raise HTTPException(400, "Результатов пока нет")
    zp = JOBS_DIR / (job_id + ".zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(JOBS_DIR / job_id))
    return FileResponse(zp, media_type="application/zip",
                        filename=f"ultrastar-{job.name.replace('/', '_')}.zip")


@app.get("/api/jobs/{job_id}/files/{file_path:path}")
def download_file(job_id: str, file_path: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "Задача не найдена")
    base = (JOBS_DIR / job_id).resolve()
    p = (base / file_path).resolve()
    if not str(p).startswith(str(base)) or not p.exists():
        raise HTTPException(404, "Файл не найден")
    return FileResponse(p, filename=p.name)


@app.get("/", response_class=HTMLResponse)
def index():
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html, headers={"Cache-Control": "no-store"})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
