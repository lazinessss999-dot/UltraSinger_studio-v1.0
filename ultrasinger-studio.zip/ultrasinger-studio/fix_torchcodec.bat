@echo off
title UltraSinger Studio - repair torchcodec
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" goto noenv
if not exist "tools\uv\uv.exe" goto noenv

echo ============================================================
echo   Fixing the DLL error window:
echo   "entry point not found  torch_get_const_data_ptr
echo    in libtorchcodec_image.dll"
echo.
echo   Reason: the torchcodec package version does not match the
echo   installed torch version. Nothing else is reinstalled here:
echo   only this one small package (about 2 MB).
echo ============================================================
echo.

set "PATH=%CD%\ffmpeg\bin;%CD%\venv\Scripts;%PATH%"
set "PYTHONUTF8=1"

echo   Current versions:
venv\Scripts\python.exe -c "import importlib.metadata as m; print('   torch      :', m.version('torch')); print('   torchcodec :', m.version('torchcodec'))" 2>nul
echo.

echo   Installing torchcodec 0.7.0, the build for torch 2.8 ...
tools\uv\uv.exe pip install -p "venv\Scripts\python.exe" --reinstall torchcodec==0.7.0
if errorlevel 1 goto failed

echo.
echo   Installing the packages whisperx needs together with it ...
tools\uv\uv.exe pip install -p "venv\Scripts\python.exe" -r "requirements-core.txt"
if errorlevel 1 goto failed

echo.
echo   Checking the result ...
venv\Scripts\python.exe -c "import torchcodec, torch; print('   torchcodec', torchcodec.__version__, 'with torch', torch.__version__)"
if errorlevel 1 goto failed

echo.
echo ============================================================
echo   DONE. Start the app with start.bat.
echo ============================================================
echo.
pause
exit /b 0

:failed
echo.
echo [ERROR] Could not repair. Check internet and antivirus,
echo         then run fix_torchcodec.bat again.
echo.
pause
exit /b 1

:noenv
echo.
echo [ERROR] Environment not found. Run install.bat first.
echo.
pause
exit /b 1
