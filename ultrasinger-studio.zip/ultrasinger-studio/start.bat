@echo off
setlocal EnableExtensions
title UltraSinger Studio

set "USROOT=%~dp0"
if "%USROOT:~-1%"=="\" set "USROOT=%USROOT:~0,-1%"

if not exist "%USROOT%\venv\Scripts\python.exe" (
  echo [ERROR] Environment not found. Run install.bat first.
  pause
  exit /b 1
)

rem ffmpeg and venv into PATH of this process; model caches stay inside the folder
set "PATH=%USROOT%\ffmpeg\bin;%USROOT%\venv\Scripts;%PATH%"
set "HF_HOME=%USROOT%\data\models\hf"
set "TORCH_HOME=%USROOT%\data\models\torch"
set "NLTK_DATA=%USROOT%\data\models\nltk"
set "US_STUDIO_HOME=%USROOT%"
set "US_DATA_DIR=%USROOT%\data"
set "US_PIPELINE_PYTHON=%USROOT%\venv\Scripts\python.exe"
set "PYTHONUTF8=1"
rem Larger read timeout for model downloads on slow links
set "HF_HUB_DOWNLOAD_TIMEOUT=90"
set "HF_HUB_ETAG_TIMEOUT=90"
rem If use_hf_mirror.bat was used, download models from the mirror
if exist "%USROOT%\hf_mirror.on" set "HF_ENDPOINT=https://hf-mirror.com"

cd /d "%USROOT%"

rem If the server is already running - just open the browser
netstat -ano | findstr "127.0.0.1:8000" | findstr "LISTENING" >nul
if not errorlevel 1 (
  echo Server is already running. Opening browser ...
  start "" http://127.0.0.1:8000
  exit /b 0
)

echo ============================================================
echo   UltraSinger Studio: http://127.0.0.1:8000
echo   First run of a song downloads AI models, 1-2 GB.
echo   Stop: close this window or run stop.bat
echo ============================================================

rem open the browser 4 seconds later, once the server is up
start /b cmd /c "timeout /t 4 /nobreak >nul & start http://127.0.0.1:8000"

"%USROOT%\venv\Scripts\python.exe" -m uvicorn web.app:app --host 127.0.0.1 --port 8000
pause
