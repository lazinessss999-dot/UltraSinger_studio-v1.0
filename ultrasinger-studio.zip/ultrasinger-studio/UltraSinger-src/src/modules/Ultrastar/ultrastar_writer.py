"""Ultrastar writer module"""

import re
import langcodes
from packaging import version

from modules.console_colors import ULTRASINGER_HEAD
from modules.Ultrastar.coverter.ultrastar_converter import (
    real_bpm_to_ultrastar_bpm,
    second_to_beat, )
from modules.Ultrastar.coverter.ultrastar_midi_converter import convert_midi_note_to_ultrastar_note
from modules.Ultrastar.ultrastar_txt import UltrastarTxtValue, UltrastarTxtTag, UltrastarTxtNoteTypeTag, \
    FILE_ENCODING
from modules.Ultrastar.ultrastar_score_calculator import Score
from modules.Midi.MidiSegment import MidiSegment


def get_multiplier(real_bpm: float) -> int:
    """Calculates the multiplier for the BPM"""

    if real_bpm == 0:
        raise Exception("BPM is 0")

    multiplier = 1
    result = 0
    while result < 400:
        result = real_bpm * multiplier
        multiplier += 1
    return multiplier - 2


def get_language_name(language: str) -> str:
    """Creates the language name from the language code"""

    return langcodes.Language.make(language=language).display_name()


# Human UltraStar charts (e.g. The Doors) look like this:
#   * 1-beat gap between every note (no sausage of touching bars)
#   * a note lasts at most ~3–4 s
#   * a lyric line is one phrase (~8 words / ~2 bars)
MAX_NOTE_BEATS = 24
MAX_LINE_BEATS = 56
MAX_LINE_WORDS = 8
MIN_GAP_BEATS = 1
PAUSE_BREAK_BEATS = 4


def _is_word_end(word: str) -> bool:
    text = word or ""
    stripped = text.rstrip()
    if text.endswith(" "):
        return True
    if stripped.endswith(("?", "!", ".", ",", ";", "…")):
        return True
    return False


def _counts_as_word(word: str) -> bool:
    stripped = (word or "").strip()
    return bool(stripped) and stripped != "~"


def _segments_to_beat_rows(
        midi_segments: list[MidiSegment],
        gap: float,
        multiplication: int,
        real_bpm: float,
) -> list[dict]:
    """Convert timed MIDI segments to UltraStar beat rows with gaps and caps."""
    raw = []
    for seg in midi_segments:
        start_time = (seg.start - gap) * multiplication
        dur_time = (seg.end - seg.start) * multiplication
        start_beat = max(0, int(round(second_to_beat(start_time, real_bpm))))
        duration = max(1, int(round(second_to_beat(dur_time, real_bpm))))
        pitch = convert_midi_note_to_ultrastar_note(seg)
        raw.append({
            "start": start_beat,
            "dur": duration,
            "pitch": pitch,
            "word": seg.word,
        })
    raw.sort(key=lambda r: (r["start"], r["dur"]))

    # Sequential notes only. UltraStar plays the file in order: a later line
    # with an earlier beat (overlapping Whisper words / leftover "~") makes
    # the lyric lag the song and shows empty bars.
    rows = []
    for row in raw:
        row["dur"] = max(1, min(row["dur"], MAX_NOTE_BEATS))
        if not rows:
            rows.append(row)
            continue
        prev = rows[-1]
        prev_end = prev["start"] + prev["dur"]
        word = (row["word"] or "").strip()
        if row["start"] < prev["start"]:
            if word == "~":
                continue
            row["start"] = prev_end + MIN_GAP_BEATS
        elif row["start"] < prev_end + MIN_GAP_BEATS:
            shrink_to = row["start"] - MIN_GAP_BEATS - prev["start"]
            if shrink_to >= 1:
                prev["dur"] = shrink_to
            elif word == "~":
                continue
            else:
                row["start"] = prev_end + MIN_GAP_BEATS
        if row["dur"] < 1:
            continue
        rows.append(row)
    return rows


def create_ultrastar_txt(
        midi_segments: list[MidiSegment],
        ultrastar_file_output: str,
        ultrastar_class: UltrastarTxtValue,
        real_bpm: float) -> None:
    """Creates an Ultrastar txt file from the automation data"""

    print(f"{ULTRASINGER_HEAD} Creating UltraStar file {ultrastar_file_output}")

    ultrastar_bpm = real_bpm_to_ultrastar_bpm(real_bpm)
    multiplication = get_multiplier(ultrastar_bpm)
    ultrastar_bpm = ultrastar_bpm * get_multiplier(ultrastar_bpm)

    with open(ultrastar_file_output, "w", encoding=FILE_ENCODING) as file:
        gap = midi_segments[0].start

        if version.parse(ultrastar_class.version) >= version.parse("1.0.0"):
            file.write(f"#{UltrastarTxtTag.VERSION.value}:{ultrastar_class.version}\n")
        file.write(f"#{UltrastarTxtTag.ARTIST.value}:{ultrastar_class.artist}\n")
        file.write(f"#{UltrastarTxtTag.TITLE.value}:{ultrastar_class.title}\n")
        if ultrastar_class.year is not None:
            file.write(f"#{UltrastarTxtTag.YEAR.value}:{ultrastar_class.year}\n")
        if ultrastar_class.language is not None:
            file.write(f"#{UltrastarTxtTag.LANGUAGE.value}:{get_language_name(ultrastar_class.language)}\n")
        if ultrastar_class.genre:
            file.write(f"#{UltrastarTxtTag.GENRE.value}:{ultrastar_class.genre}\n")
        if ultrastar_class.cover is not None:
            file.write(f"#{UltrastarTxtTag.COVER.value}:{ultrastar_class.cover}\n")
        if version.parse(ultrastar_class.version) >= version.parse("1.2.0"):
            if ultrastar_class.coverUrl is not None:
                file.write(f"#{UltrastarTxtTag.COVERURL.value}:{ultrastar_class.coverUrl}\n")
        if ultrastar_class.background is not None:
            file.write(f"#{UltrastarTxtTag.BACKGROUND.value}:{ultrastar_class.background}\n")
        file.write(f"#{UltrastarTxtTag.MP3.value}:{ultrastar_class.mp3}\n")
        if version.parse(ultrastar_class.version) >= version.parse("1.1.0"):
            file.write(f"#{UltrastarTxtTag.AUDIO.value}:{ultrastar_class.audio}\n")
            if ultrastar_class.vocals is not None:
                file.write(f"#{UltrastarTxtTag.VOCALS.value}:{ultrastar_class.vocals}\n")
            if ultrastar_class.instrumental is not None:
                file.write(f"#{UltrastarTxtTag.INSTRUMENTAL.value}:{ultrastar_class.instrumental}\n")
        if ultrastar_class.video is not None:
            file.write(f"#{UltrastarTxtTag.VIDEO.value}:{ultrastar_class.video}\n")
        if ultrastar_class.videoGap is not None:
            file.write(f"#{UltrastarTxtTag.VIDEOGAP.value}:{ultrastar_class.videoGap}\n")
        if version.parse(ultrastar_class.version) >= version.parse("1.2.0"):
            if ultrastar_class.videoUrl is not None:
                file.write(f"#{UltrastarTxtTag.VIDEOURL.value}:{ultrastar_class.videoUrl}\n")
        file.write(f"#{UltrastarTxtTag.BPM.value}:{round(ultrastar_bpm, 2)}\n")  # not the real BPM!
        file.write(f"#{UltrastarTxtTag.GAP.value}:{int(gap * 1000)}\n")
        if version.parse(ultrastar_class.version) >= version.parse("1.1.0"):
            if ultrastar_class.tags is not None:
                file.write(f"#{UltrastarTxtTag.TAGS.value}:{ultrastar_class.tags}\n")
        file.write(f"#{UltrastarTxtTag.CREATOR.value}:{ultrastar_class.creator}\n")
        file.write(f"#{UltrastarTxtTag.COMMENT.value}:{ultrastar_class.comment}\n")

        rows = _segments_to_beat_rows(midi_segments, gap, multiplication, real_bpm)
        line_start_beat = rows[0]["start"] if rows else 0
        words_in_line = 0

        for i, row in enumerate(rows):
            file.write(
                f"{UltrastarTxtNoteTypeTag.NORMAL.value} "
                f"{row['start']} "
                f"{row['dur']} "
                f"{row['pitch']} "
                f"{row['word']}\n"
            )

            if _counts_as_word(row["word"]) and _is_word_end(row["word"]):
                words_in_line += 1

            if i >= len(rows) - 1:
                continue

            nxt = rows[i + 1]
            silence_beats = nxt["start"] - (row["start"] + row["dur"])
            line_beats = (row["start"] + row["dur"]) - line_start_beat
            stripped = (row["word"] or "").rstrip()
            should_break = False
            if silence_beats >= PAUSE_BREAK_BEATS:
                should_break = True
            elif _is_word_end(row["word"]):
                if words_in_line >= MAX_LINE_WORDS:
                    should_break = True
                elif line_beats >= MAX_LINE_BEATS:
                    should_break = True
                elif stripped.endswith(("?", "!", ".")):
                    should_break = True

            if should_break:
                file.write(
                    f"{UltrastarTxtTag.LINEBREAK.value} "
                    f"{row['start'] + row['dur']}\n"
                )
                line_start_beat = nxt["start"]
                words_in_line = 0
        file.write(f"{UltrastarTxtTag.FILE_END.value}")


def deviation(silence_parts):
    """Calculates the deviation of the silence parts"""

    if len(silence_parts) < 5:
        return 0

    # Remove the longest part so the deviation is not that high
    sorted_parts = sorted(silence_parts)
    filtered_parts = [part for part in sorted_parts if part < sorted_parts[-1]]

    sum_parts = sum(filtered_parts)
    if sum_parts == 0:
        return 0

    mean = sum_parts / len(filtered_parts)
    return mean


def calculate_silent_beat_length(midi_segments: list[MidiSegment]):
    print(f"{ULTRASINGER_HEAD} Calculating silence parts for linebreaks.")

    silent_parts = []
    for i, data in enumerate(midi_segments):
        if i < len(midi_segments) - 1:
            silent_parts.append(midi_segments[i + 1].start - data.end)

    return deviation(silent_parts)


def create_repitched_txt_from_ultrastar_data(
        input_file: str, note_numbers: list[int], output_repitched_ultrastar: str
) -> None:
    """Creates a repitched ultrastar txt file from the original one"""
    # todo: just add '_repitched' to input_file
    print(f"{ULTRASINGER_HEAD} Creating repitched ultrastar txt -> {input_file}_repitch.txt")

    # todo: to reader
    with open(input_file, "r", encoding=FILE_ENCODING) as file:
        txt = file.readlines()

    i = 0
    # todo: just add '_repitched' to input_file
    with open(output_repitched_ultrastar, "w", encoding=FILE_ENCODING) as file:
        for line in txt:
            if line.startswith(f"{UltrastarTxtNoteTypeTag.NORMAL.value} "):
                parts = re.findall(r"\S+|\s+", line)
                # between are whitespaces
                # [0] :
                # [2] start beat
                # [4] duration
                # [6] pitch
                # [8] word
                parts[6] = str(note_numbers[i])
                delimiter = ""
                file.write(delimiter.join(parts))
                i += 1
            else:
                file.write(line)


def add_score_to_ultrastar_txt(ultrastar_file_output: str, score: Score) -> None:
    """Adds the score to the ultrastar txt file"""
    with open(ultrastar_file_output, "r", encoding=FILE_ENCODING) as file:
        text = file.read()
    text = text.split("\n")

    for i, line in enumerate(text):
        if line.startswith(f"#{UltrastarTxtTag.COMMENT.value}:"):
            text[
                i
            ] = f"{line} | Score: total: {score.score}, notes: {score.notes} line: {score.line_bonus}, golden: {score.golden}"
            break

        if line.startswith((
                f"{UltrastarTxtNoteTypeTag.FREESTYLE.value} ",
                f"{UltrastarTxtNoteTypeTag.NORMAL.value} ",
                f"{UltrastarTxtNoteTypeTag.GOLDEN.value} ",
                f"{UltrastarTxtNoteTypeTag.RAP.value} ",
                f"{UltrastarTxtNoteTypeTag.RAP_GOLDEN.value} ")):
            text.insert(
                i,
                f"#{UltrastarTxtTag.COMMENT.value}: UltraSinger [GitHub] | Score: total: {score.score}, notes: {score.notes} line: {score.line_bonus}, golden: {score.golden}",
            )
            break

    text = "\n".join(text)

    with open(ultrastar_file_output, "w", encoding=FILE_ENCODING) as file:
        file.write(text)


class UltraStarWriter:
    """Docstring"""


def format_separated_string(data: str) -> str:
    temp = re.sub(r'[;/]', ',', data)
    words = temp.split(',')
    words = [s for s in words if s.strip()]

    for i, word in enumerate(words):
        if "-" not in word:
            words[i] = word.strip().capitalize() + ', '
        else:
            dash_words = word.split('-')
            capitalized_dash_words = [dash_word.strip().capitalize() for dash_word in dash_words]
            formatted_dash_word = '-'.join(capitalized_dash_words) + ', '
            words[i] = formatted_dash_word

    formatted_string = ''.join(words)

    if formatted_string.endswith(', '):
        formatted_string = formatted_string[:-2]

    return formatted_string
