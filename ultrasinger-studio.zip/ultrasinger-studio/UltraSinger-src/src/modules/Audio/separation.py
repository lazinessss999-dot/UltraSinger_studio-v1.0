"""Separate vocals from audio"""
import os
from enum import Enum

import demucs.separate

from modules.console_colors import (
    ULTRASINGER_HEAD,
    blue_highlighted,
    red_highlighted, green_highlighted,
)
from modules.os_helper import check_file_exists

class DemucsModel(Enum):
    HTDEMUCS = "htdemucs"           # first version of Hybrid Transformer Demucs. Trained on MusDB + 800 songs. Default model.
    HTDEMUCS_FT = "htdemucs_ft"     # fine-tuned version of htdemucs, separation will take 4 times more time but might be a bit better. Same training set as htdemucs.
    HTDEMUCS_6S = "htdemucs_6s"     # 6 sources version of htdemucs, with piano and guitar being added as sources. Note that the piano source is not working great at the moment.
    HDEMUCS_MMI = "hdemucs_mmi"     # Hybrid Demucs v3, retrained on MusDB + 800 songs.
    MDX = "mdx"                     # trained only on MusDB HQ, winning model on track A at the MDX challenge.
    MDX_EXTRA = "mdx_extra"         # trained with extra training data (including MusDB test set), ranked 2nd on the track B of the MDX challenge.
    MDX_Q = "mdx_q"                 # quantized version of the previous models. Smaller download and storage but quality can be slightly worse.
    MDX_EXTRA_Q = "mdx_extra_q"     # quantized version of mdx_extra. Smaller download and storage but quality can be slightly worse.
    SIG = "SIG"                     # Placeholder for a single model from the model zoo.

#: Quantized demucs models need the `diffq` package. diffq is published as
#: source only for Python 3.11+ (the newest Windows wheel is cp310), so
#: installing it requires Visual C++ Build Tools - that is why demucs aborts
#: with "FATAL: Trying to use DiffQ, but diffq is not installed."
QUANTIZED_FALLBACK = {
    DemucsModel.MDX_Q: DemucsModel.MDX,
    DemucsModel.MDX_EXTRA_Q: DemucsModel.MDX_EXTRA,
}


def diffq_available() -> bool:
    try:
        import diffq  # noqa: F401
        return True
    except Exception:
        return False


def resolve_demucs_model(model: DemucsModel) -> DemucsModel:
    """Replace a quantized demucs model with its plain version if diffq is missing."""
    if model in QUANTIZED_FALLBACK and not diffq_available():
        replacement = QUANTIZED_FALLBACK[model]
        print(
            f"{ULTRASINGER_HEAD} The quantized model {blue_highlighted(model.value)} needs the "
            f"{blue_highlighted('diffq')} package, which cannot be installed on this system "
            f"(no prebuilt build for this Python). Using {green_highlighted(replacement.value)} instead."
        )
        return replacement
    return model


def separate_audio(input_file_path: str, output_folder: str, model: DemucsModel, device="cpu") -> None:
    """Separate vocals from audio with demucs."""

    # Safety net: every caller (CLI flag, interactive mode, the web app) ends up
    # here, so a quantized model is replaced even if the argument parsing was
    # bypassed.
    model = resolve_demucs_model(model)

    print(
        f"{ULTRASINGER_HEAD} Separating vocals from audio with {blue_highlighted('demucs')} with model {blue_highlighted(model.value)} and {red_highlighted(device)} as worker."
    )

    demucs.separate.main(
        [
            "--two-stems", "vocals",
            "-d", f"{device}",
            "--float32",
            "-n",
            model.value,
            "--out", f"{os.path.join(output_folder, 'separated')}",
            f"{input_file_path}",
        ]
    )

def separate_vocal_from_audio(cache_folder_path: str,
                              audio_output_file_path: str,
                              use_separated_vocal: bool,
                              create_karaoke: bool,
                              pytorch_device: str,
                              model: DemucsModel,
                              skip_cache: bool = False) -> str:
    """Separate vocal from audio"""
    demucs_output_folder = os.path.splitext(os.path.basename(audio_output_file_path))[0]
    audio_separation_path = os.path.join(cache_folder_path, "separated", model.value, demucs_output_folder)

    vocals_path = os.path.join(audio_separation_path, "vocals.wav")
    instrumental_path = os.path.join(audio_separation_path, "no_vocals.wav")
    if use_separated_vocal or create_karaoke:
        cache_available = check_file_exists(vocals_path) and check_file_exists(instrumental_path)
        if skip_cache or not cache_available:
            separate_audio(audio_output_file_path, cache_folder_path, model, pytorch_device)
        else:
            print(f"{ULTRASINGER_HEAD} {green_highlighted('cache')} reusing cached separated vocals")

    return audio_separation_path
