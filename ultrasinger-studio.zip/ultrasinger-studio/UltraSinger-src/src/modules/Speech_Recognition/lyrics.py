"""Lyrics support: user provided lyrics + forced alignment helpers.

This module loads lyrics that the user supplied (plain ``.txt`` or ``.lrc`` with
line timings), turns them into whisperx style segments so that the existing
forced alignment can put the *real* words onto the audio timeline, and repairs
words that the aligner dropped.

Only the standard library is used on purpose: the web UI imports this module as
well and must never pull in torch/whisperx.
"""

from __future__ import annotations

import difflib
import os
import re

LRC_TIME = re.compile(r"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]")
LRC_WORD = re.compile(r"<(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?>")
LRC_META = re.compile(
    r"\[(ti|ar|al|by|offset|length|re|ve|au):([^\]]*)\]", re.IGNORECASE
)
HTML_TAG = re.compile(r"<[a-z/][^>]{0,80}>", re.IGNORECASE)
TRACK_PREFIX = re.compile(r"^\s*\d{1,3}\s*[-._)\]]\s*")
NAME_SEPARATORS = (" - ", " – ", " — ", " − ", "-", " _ ", "_")
UNKNOWN_NAME = re.compile(r"^unknown(?:\s+artist|\s+title)?$", re.IGNORECASE)

SECTION_WORDS = {
    "куплет", "припев", "бридж", "проигрыш", "вступление", "интро", "аутро",
    "кода", "соло", "финал", "речитатив", "запев",
    "verse", "chorus", "bridge", "intro", "outro", "solo", "hook", "refrain",
    "instrumental", "pre-chorus", "prechorus", "adlib", "ad-lib",
}


def _to_seconds(minutes, seconds, fraction):
    value = int(minutes) * 60 + int(seconds)
    if fraction:
        value += int(fraction) / (10 ** len(fraction))
    return round(value, 3)


def _is_section_line(line: str) -> bool:
    """True for labels like 'Припев:', '[Куплет 2]', 'Chorus x2' - not sung."""
    text = line.strip()
    if not text:
        return True
    stripped = text.strip("[](){}").strip().strip(":").strip()
    if not stripped:
        return True
    if not re.search(r"[^\W\d_]", stripped, re.UNICODE):
        return True
    low = stripped.lower()
    first = re.split(r"[\s\d:.,;!—-]+", low)[0]
    if first in SECTION_WORDS:
        rest = low[len(first):].strip(" .,:;-")
        return bool(
            re.fullmatch(r"(?:[\d\s.,:;xх×*/+-]|раза?|times?|раз)?", rest)
        )
    return False


def _is_junk_line(line: str) -> bool:
    text = line.strip()
    if not text:
        return True
    if re.fullmatch(r"[\s\-–—_*~=•·.]+", text):
        return True
    return len(re.sub(r"[^\w]", "", text, flags=re.UNICODE)) < 2


def normalize_word(word: str) -> str:
    """Lowercase, yo->ye, punctuation removed - used for fuzzy matching."""
    value = word.lower().replace("ё", "е").replace("\u2019", "'")
    value = re.sub(r"[\W_]+", "", value, flags=re.UNICODE)
    return value


def usable_name(value: str) -> str:
    """Empty string for missing / 'Unknown Artist' placeholders."""
    text = (value or "").strip()
    if not text or UNKNOWN_NAME.match(text):
        return ""
    return text


def split_artist_title(name: str) -> tuple[str, str]:
    """Artist / title from a file stem such as ``01 - Мельница - Вереск``.

    A leading track number is stripped, then the first hyphen-like separator
    splits artist and title. If nothing looks like a split, artist is empty
    and title is the cleaned name.
    """
    stem = os.path.splitext(os.path.basename(name or ""))[0]
    stem = TRACK_PREFIX.sub("", stem).strip()
    for separator in NAME_SEPARATORS:
        if separator in stem:
            left, right = stem.split(separator, 1)
            left, right = left.strip(), right.strip()
            if len(left) > 1 and len(right) > 1:
                return left, right
    return "", stem.strip()


def detect_language(text: str):
    """Return 'ru' when the text is written mostly in Cyrillic, else None."""
    cyrillic = len(re.findall(r"[а-яё]", text, re.IGNORECASE))
    latin = len(re.findall(r"[a-z]", text, re.IGNORECASE))
    if cyrillic >= 8 and cyrillic >= latin:
        return "ru"
    return None


def looks_like_lyrics(text: str) -> bool:
    """Reject search noise, HTML dumps and one-liners."""
    if not text or HTML_TAG.search(text):
        return False
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) < 4:
        return False
    # timestamps and metadata are not letters - drop them before the ratio test
    body = LRC_META.sub("", LRC_TIME.sub("", LRC_WORD.sub("", text)))
    letters = len(re.findall(r"[^\W\d_]", body, re.UNICODE))
    return letters >= 45 and letters / max(len(body), 1) > 0.5


def parse_lyrics_text(text: str) -> dict:
    """Parse plain lyrics or an .lrc file.

    Returns a dict with:
      ``lines``       - all lyric lines in order (no metadata, no labels)
      ``timed``       - ``[(seconds, line), ...]`` when the file has timings
      ``timed_words`` - ``[(line_index, [(seconds, word), ...]), ...]`` for LRC
                        files that carry per word timings (enhanced LRC)
      ``meta``        - ``[ti:]``/``[ar:]``/``[offset:]`` values
      ``is_lrc``      - whether line timings were found
    """
    if not text:
        return {"lines": [], "timed": [], "timed_words": [], "meta": {}, "is_lrc": False}

    lines, timed, timed_words, meta = [], [], [], {}
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        for key, value in LRC_META.findall(raw):
            meta[key.lower()] = value.strip()

        stamps = LRC_TIME.findall(raw)
        body = LRC_META.sub("", LRC_TIME.sub("", raw))

        word_times = []
        if LRC_WORD.search(body):
            matches = list(LRC_WORD.finditer(body))
            for index, match in enumerate(matches):
                end = matches[index + 1].start() if index + 1 < len(matches) else len(body)
                chunk = body[match.end():end].strip()
                if chunk:
                    word_times.append((_to_seconds(*match.groups()), chunk))
            body = LRC_WORD.sub("", body)

        body = body.strip()
        if not body or _is_section_line(body) or _is_junk_line(body):
            continue

        if stamps:
            for stamp in stamps:
                seconds = _to_seconds(*stamp)
                timed.append((seconds, body))
                lines.append(body)
                line_index = len(lines) - 1
                if word_times:
                    timed_words.append((line_index, list(word_times)))
        else:
            lines.append(body)

    if timed:
        offset = meta.get("offset")
        if offset:
            try:
                shift = int(offset.strip()) / 1000.0
            except ValueError:
                shift = 0.0
            if shift:
                timed = [(max(0.0, seconds - shift), text) for seconds, text in timed]

    cleaned = _dedupe_labels(lines)
    if len(cleaned) != len(lines):
        lines = cleaned
    return {
        "lines": lines,
        "timed": timed,
        "timed_words": timed_words,
        "meta": meta,
        "is_lrc": bool(timed),
    }


def _dedupe_labels(lines):
    """Drop a label line that repeats right before the same label (e.g. '[Chorus]')."""
    result = []
    for line in lines:
        result.append(line)
    return result


def decode_bytes(data: bytes) -> str:
    """Decode lyrics bytes: UTF-8 (with BOM), then cp1251, then latin-1."""
    for encoding in ("utf-8-sig", "cp1251", "utf-16", "latin-1"):
        try:
            return data.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", errors="replace")


def load_lyrics_file(path: str) -> dict:
    """Read a .txt/.lrc lyrics file and parse it."""
    with open(path, "rb") as handle:
        data = handle.read()
    result = parse_lyrics_text(decode_bytes(data))
    result["path"] = path
    return result


def write_lyrics_file(path: str, text: str) -> str:
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text if text.endswith("\n") else text + "\n")
    return path


def segments_from_timed(timed, duration: float = 0.0, last_line_seconds: float = 12.0):
    """Build whisperx segments from [(start_seconds, text)] line timings."""
    segments = []
    total = len(timed)
    for index, (start, text) in enumerate(timed):
        start = max(0.0, float(start))
        if index + 1 < total:
            end = float(timed[index + 1][0])
        else:
            end = start + last_line_seconds
            if duration:
                end = min(end, float(duration))
        if end <= start:
            end = start + 1.0
        if end - start < 0.6:
            end = start + 0.6
        segments.append({"text": text, "start": round(start, 3), "end": round(end, 3)})
    return segments


def _word_times(words):
    """Normalize a whisper word list into (index, start, end, word) tuples."""
    output = []
    for word in words:
        value = (word.get("word") or "").strip()
        start, end = word.get("start"), word.get("end")
        if not value or start is None or end is None:
            continue
        if not normalize_word(value):
            continue
        output.append((len(output), float(start), float(end), value))
    return output


def map_lines_to_timeline(lines, words, duration: float = 0.0, min_match_ratio: float = 0.25):
    """Place user lyrics lines on the timeline using whisper word timings.

    Whisper makes mistakes in the words (that is why the user supplies lyrics)
    but its timings are good. This matches the *correct* lyric words against
    whisper's words with a monotonic fuzzy match, interpolates the gaps and
    returns segments ready for whisperx.align - or None when the match is too
    weak to be trusted.
    """
    tokens = _word_times(words or [])
    lyrics = []
    for line_index, line in enumerate(lines or []):
        for word in line.split():
            if normalize_word(word):
                lyrics.append((line_index, word))
    if not lyrics or len(tokens) < 3:
        return None

    lyric_norm = [normalize_word(word) for _, word in lyrics]
    whisper_norm = [normalize_word(item[3]) for item in tokens]
    matcher = difflib.SequenceMatcher(None, lyric_norm, whisper_norm, autojunk=False)

    anchors = {}
    blocks = []
    for a, b, size in matcher.get_matching_blocks():
        if size:
            blocks.append((a, b, size))
        for offset in range(size):
            anchors[a + offset] = (tokens[b + offset][1], tokens[b + offset][2])
    if len(anchors) < max(3, int(len(lyrics) * min_match_ratio)):
        return None

    # Words between two matches are usually the ones whisper heard differently
    # ("скоро" -> "скаро"). Those tokens still sit at the right place in time, so
    # pair the un-matched lyric words with the un-matched tokens in order
    # instead of interpolating a position across a possible pause.
    for (a1, b1, size1), (a2, b2, _size2) in zip(blocks, blocks[1:]):
        lyric_start, lyric_stop = a1 + size1, a2
        token_start, token_stop = b1 + size1, b2
        missing = lyric_stop - lyric_start
        spare = token_stop - token_start
        if missing <= 0 or spare <= 0:
            continue
        for offset in range(missing):
            token_index = token_start + min(spare - 1, (offset * spare) // missing)
            anchors.setdefault(
                lyric_start + offset, (tokens[token_index][1], tokens[token_index][2])
            )

    index_list = sorted(anchors)
    positions = {}
    for index in range(len(lyrics)):
        if index in anchors:
            positions[index] = anchors[index]
            continue
        previous = max((j for j in index_list if j < index), default=None)
        following = min((j for j in index_list if j > index), default=None)
        if previous is None and following is None:
            continue
        if previous is None:
            start = max(0.0, anchors[following][0] - 0.4 * (following - index))
            positions[index] = (start, start + 0.25)
        elif following is None:
            start = anchors[previous][1] + 0.25 * (index - previous)
            positions[index] = (start, start + 0.25)
        else:
            gap = anchors[following][0] - anchors[previous][1]
            fraction = (index - previous) / float(following - previous)
            start = anchors[previous][1] + gap * fraction
            duration_each = max(0.12, gap / max(following - previous, 1) * 0.8)
            positions[index] = (start, start + duration_each)

    per_line = {}
    for index, (line_index, _word) in enumerate(lyrics):
        if index not in positions:
            continue
        start, end = positions[index]
        current = per_line.get(line_index)
        if current is None:
            per_line[line_index] = [start, end]
        else:
            current[0] = min(current[0], start)
            current[1] = max(current[1], end)
    if not per_line:
        return None

    segments = []
    ordered = sorted(per_line)
    for line_index in ordered:
        start, end = per_line[line_index]
        segments.append(
            {
                "text": lines[line_index],
                "start": round(max(0.0, start - 0.35), 3),
                "end": round(end + 0.45, 3),
            }
        )
    # keep windows monotonic and inside the audio
    for index, segment in enumerate(segments):
        if index and segment["start"] < segments[index - 1]["start"]:
            segment["start"] = segments[index - 1]["start"]
        if segment["end"] <= segment["start"]:
            segment["end"] = segment["start"] + 1.0
        if duration:
            segment["end"] = min(segment["end"], float(duration))
            segment["start"] = min(segment["start"], float(duration))
    return segments


def proportional_segments(lines, start: float, end: float):
    """Last resort: spread lines over a span, weighted by word count."""
    weights = [max(1, len(line.split())) for line in lines]
    total = float(sum(weights))
    segments = []
    cursor = float(start)
    span = max(1.0, float(end) - float(start))
    for line, weight in zip(lines, weights):
        share = span * weight / total
        segments.append(
            {"text": line, "start": round(cursor, 3), "end": round(cursor + share, 3)}
        )
        cursor += share
    return segments


def word_timings_from_lrc(parsed, min_coverage: float = 0.8):
    """Return ``[(word, start, end), ...]`` when the file has per word timings.

    Enhanced LRC files (NetEase/QQ music and friends) already contain the exact
    moments of every word, so no aligner and no GPU are needed at all.
    """
    timed_words = parsed.get("timed_words") or []
    lines = parsed.get("lines") or []
    if not timed_words or not lines:
        return None
    if len(timed_words) < max(2, int(len(lines) * min_coverage)):
        return None
    timings = []
    for _line_index, pairs in timed_words:
        for index, (start, text) in enumerate(pairs):
            end = pairs[index + 1][0] if index + 1 < len(pairs) else start + 0.4
            words = [word for word in text.split() if normalize_word(word)]
            if not words:
                continue
            step = max(0.08, (end - start) / len(words))
            for offset, word in enumerate(words):
                timings.append(
                    (word, round(start + offset * step, 3), round(start + (offset + 1) * step, 3))
                )
    if len(timings) < 4:
        return None
    timings.sort(key=lambda item: item[1])
    return timings


def repair_missing_words(expected_lines, produced_words, min_gap_ratio: float = 0.35):
    """Find lyric words the aligner dropped and give them interpolated times.

    Only runs of words that fall into a real gap (>= 1.5 s) between two matched
    neighbours are repaired - a word that simply is not in the recording stays
    untouched instead of being invented somewhere random.
    """
    tokens = _word_times(produced_words or [])
    lyrics = [
        word
        for line in (expected_lines or [])
        for word in line.split()
        if normalize_word(word)
    ]
    if not lyrics or len(tokens) < 3:
        return []
    lyric_norm = [normalize_word(word) for word in lyrics]
    whisper_norm = [normalize_word(item[3]) for item in tokens]
    matcher = difflib.SequenceMatcher(None, lyric_norm, whisper_norm, autojunk=False)
    matched = {}
    for a, b, size in matcher.get_matching_blocks():
        for offset in range(size):
            matched[a + offset] = (tokens[b + offset][1], tokens[b + offset][2])
    if not matched:
        return []
    ordered = sorted(matched)

    repairs = []
    run = []
    for index in range(len(lyrics)):
        if index in matched:
            if run:
                before = max((j for j in ordered if j < run[0]), default=None)
                after = min((j for j in ordered if j > run[-1]), default=None)
                if before is not None and after is not None:
                    gap = matched[after][0] - matched[before][1]
                    expected_gap = 1.2 + 0.35 * len(run)
                    if gap >= expected_gap:
                        step = gap / (len(run) + 1)
                        for offset, missing in enumerate(run):
                            start = matched[before][1] + step * (offset + 1)
                            repairs.append(
                                {"word": lyrics[missing], "start": round(start, 3),
                                 "end": round(start + min(0.35, step * 0.8), 3)}
                            )
            run = []
        else:
            run.append(index)
    return repairs
