"""Whisper Speech Recognition Module"""
import os
import inspect
import textwrap

# Set environment variable to handle cuDNN loading issues
# CUDA_MODULE_LOADING=LAZY allows PyTorch to continue even if some cuDNN modules are not found
#os.environ['CUDA_MODULE_LOADING'] = 'LAZY'

import torch

# Fix for PyTorch 2.6+ compatibility with omegaconf and old models
# MUST be done before importing whisperx or any other modules that use torch.load
# Monkey-patch torch.load to use weights_only=False for compatibility with older models
# This is necessary because PyTorch 2.6+ changed the default to weights_only=True
# but WhisperX/Pyannote models were saved with pickle and require weights_only=False
_original_torch_load = torch.load
def _patched_torch_load(*args, **kwargs):
    # Force weights_only=False regardless of what was passed
    kwargs['weights_only'] = False
    return _original_torch_load(*args, **kwargs)
torch.load = _patched_torch_load

import whisperx
from enum import Enum
from torch.cuda import OutOfMemoryError

from modules.Speech_Recognition.TranscriptionResult import TranscriptionResult
from modules.console_colors import ULTRASINGER_HEAD, blue_highlighted, green_highlighted, red_highlighted
from modules.Speech_Recognition.TranscribedData import TranscribedData, from_whisper
from modules.Speech_Recognition.lyrics import (
    detect_language,
    load_lyrics_file,
    map_lines_to_timeline,
    proportional_segments,
    repair_missing_words,
    segments_from_timed,
    word_timings_from_lrc,
)

#Addition for numbers to words
import re
import ast
from num2words import num2words

#Addition for numbers to words
re_split_preserve_space = re.compile(r'(\d+|\W+|\w+)')

#: Compute types ordered by preference (fastest first) for each device.
_COMPUTE_PREFERENCE = {
    "cuda": ["float16", "int8_float16", "int8_float32", "float32"],
    "cpu": ["int8", "int8_float32", "float32"],
}


def default_compute_type(device: str = "cuda") -> str:
    """Pick a compute type that the actual hardware supports.

    Not every CUDA card can do float16: ctranslate2 enables it only from
    compute capability 7.0 (GeForce 20xx and newer). On older cards such as
    the GTX 1070 (6.1) float16 fails with
    "Requested float16 compute type, but the target device or backend do not
    support efficient float16 computation". ctranslate2 can tell us exactly
    what a device supports, so ask it instead of guessing.
    """
    target = "cuda" if device == "cuda" else "cpu"
    try:
        import ctranslate2
        supported = set(ctranslate2.get_supported_compute_types(target, 0))
    except Exception:
        supported = set()
    for candidate in _COMPUTE_PREFERENCE[target]:
        if candidate in supported:
            return candidate
    return "int8" if target == "cpu" else "float32"


MEMORY_ERROR_MESSAGE = f"{ULTRASINGER_HEAD} {blue_highlighted('whisper')} ran out of GPU memory; reduce --whisper_batch_size or force usage of cpu with --force_cpu"

class WhisperModel(Enum):
    """Whisper model"""
    TINY = "tiny"
    BASE = "base"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE_V1 = "large-v1"
    LARGE_V2 = "large-v2"
    LARGE_V3 = "large-v3"

#Addition for numbers to words (Using previous code from louispan in PR#135)
def number_to_words(line,language='en'):
    # https://github.com/m-bain/whisperX
    # Transcript words which do not contain characters in the alignment models dictionary e.g. "2014." or "£13.60" cannot be aligned and therefore are not given a timing.
    # Therefore, convert numbers to words
    out_tokens = []
    in_tokens = re_split_preserve_space.findall(line)
    for token in in_tokens:
        try:
            num = ast.literal_eval(token)
            try:
                out_tokens.append(num2words(num, lang=language))
            except NotImplementedError:
                print(
                    f"{ULTRASINGER_HEAD} {red_highlighted('Error:')} Unknown language for number transcription. Keeping number as numeric characters for line: {line}, token: {token}"
                )
        except Exception:
            out_tokens.append(token)
    return ''.join(out_tokens) 

def replace_code_lines(source, start_token, end_token,
                       replacement, escape_tokens=True):
    """Replace the source code between `start_token` and `end_token`
    in `source` with `replacement`. The `start_token` portion is included
    in the replaced code. If `escape_tokens` is True (default),
    escape the tokens to avoid them being treated as a regular expression."""

    if escape_tokens:
        start_token = re.escape(start_token)
        end_token = re.escape(end_token)

    def replace_with_indent(match):
        indent = match.group(1)
        return textwrap.indent(replacement, indent)

    return re.sub(r"^(\s+)({}[\s\S]+?)(?=^\1{})".format(start_token, end_token),
                  replace_with_indent, source, flags=re.MULTILINE)

def _flatten_words(segments) -> list:
    """All word dicts of whisper segments in one flat list."""
    words = []
    for segment in segments or []:
        words.extend(segment.get("words") or [])
    return words


def _words_without_timings(segments) -> list:
    """Pseudo word timings from segment timings, for whisper builds that
    return no word level data."""
    words = []
    for segment in segments or []:
        text_words = [word for word in (segment.get("text") or "").split() if word.strip()]
        start, end = segment.get("start"), segment.get("end")
        if not text_words or start is None or end is None:
            continue
        step = max(0.05, (float(end) - float(start)) / len(text_words))
        for index, word in enumerate(text_words):
            words.append(
                {
                    "word": word,
                    "start": float(start) + index * step,
                    "end": float(start) + (index + 1) * step,
                }
            )
    return words


def transcribed_data_from_word_timings(word_timings, confidence: float = 1.0):
    """Build TranscribedData items from ``[(word, start, end), ...]``."""
    data = []
    for word, start, end in word_timings:
        item = TranscribedData()
        item.word = word + " "
        item.start = float(start)
        item.end = float(end)
        item.confidence = confidence
        data.append(item)
    return data


def transcribe_with_whisper(
    audio_path: str,
    model: WhisperModel,
    device="cpu",
    alignment_model: str = None,
    batch_size: int = 16,
    compute_type: str = None,
    language: str = None,
    keep_numbers: bool = False,
    lyrics_file: str = None,
) -> TranscriptionResult:
    """Transcribe with whisper - or put lyrics provided by the user onto the audio.

    When ``lyrics_file`` is given the words of that file are aligned to the
    audio (forced alignment): whisper is not asked for the words any more, only
    for the timing of them when no LRC timings are available. That is what makes
    the final UltraStar text match the real lyrics.
    """
    lyrics = None
    if lyrics_file:
        try:
            lyrics = load_lyrics_file(lyrics_file)
            if lyrics["lines"]:
                print(
                    f"{ULTRASINGER_HEAD} Using {blue_highlighted('own lyrics')} from "
                    f"{blue_highlighted(os.path.basename(lyrics_file))} "
                    f"({len(lyrics['lines'])} lines, "
                    f"{'with timings' if lyrics['is_lrc'] else 'plain text'})"
                )
            else:
                lyrics = None
        except Exception as error:  # noqa: BLE001 - never fail the run because of lyrics
            print(f"{ULTRASINGER_HEAD} {red_highlighted('Warning:')} could not read lyrics file '{lyrics_file}': {error}")
            lyrics = None

    if compute_type is None:
        compute_type = default_compute_type(device)

    try:
        torch.cuda.empty_cache()
        audio = whisperx.load_audio(audio_path)
        duration = float(audio.shape[0]) / 16000.0 if hasattr(audio, "shape") else 0.0

        # 1. Per word timings inside the lyrics file: nothing to align, no GPU needed.
        if lyrics is not None:
            direct = word_timings_from_lrc(lyrics)
            if direct:
                detected = language or detect_language(" ".join(lyrics["lines"]))
                print(
                    f"{ULTRASINGER_HEAD} The lyrics file has {blue_highlighted('per word timings')} - "
                    f"using them directly, whisper and the aligner are not needed"
                )
                return TranscriptionResult(transcribed_data_from_word_timings(direct), detected)

        # 2. Line timings (normal .lrc): whisper is not needed for the words either.
        if lyrics is not None and lyrics["timed"]:
            detected = language or detect_language(" ".join(lyrics["lines"]))
            print(
                f"{ULTRASINGER_HEAD} {green_highlighted('Using line timings')} from the lyrics file "
                f"({len(lyrics['timed'])} lines) - whisper transcription is skipped"
            )
            segments = segments_from_timed(lyrics["timed"], duration)
            language = detected
        else:
            print(
                f"{ULTRASINGER_HEAD} Loading {blue_highlighted('whisper')} with model "
                f"{blue_highlighted(model.value)} and {red_highlighted(device)} as worker"
            )
            if alignment_model is not None:
                print(f"{ULTRASINGER_HEAD} using alignment model {blue_highlighted(alignment_model)}")

            loaded_whisper_model = whisperx.load_model(
                model.value, language=language, device=device, compute_type=compute_type
            )
            print(f"{ULTRASINGER_HEAD} Transcribing {audio_path}")
            result = loaded_whisper_model.transcribe(
                audio, batch_size=batch_size, language=language
            )
            detected_language = result.get("language") or language or "en"
            language = detected_language

            if lyrics is not None:
                words = _flatten_words(result["segments"]) or _words_without_timings(result["segments"])
                segments = map_lines_to_timeline(lyrics["lines"], words, duration=duration)
                if segments is None:
                    start = words[0].get("start") if words and words[0].get("start") is not None else 0.0
                    end = words[-1].get("end") if words and words[-1].get("end") is not None else duration
                    segments = proportional_segments(lyrics["lines"], start or 0.0, end or duration)
                    print(
                        f"{ULTRASINGER_HEAD} {red_highlighted('Warning:')} could not match the lyrics to the "
                        f"whisper timings - spreading the lines proportionally. Check the language setting."
                    )
                else:
                    print(
                        f"{ULTRASINGER_HEAD} {green_highlighted('Matched')} the lyrics to the whisper "
                        f"timings ({len(segments)} lines keep the words from your file)"
                    )
            else:
                segments = result["segments"]

        if language is None:
            language = detect_language(" ".join(lyrics["lines"])) if lyrics else None
        if language is None:
            language = "en"

        if keep_numbers is False:
            for obj in segments:
                obj["text"] = number_to_words(obj["text"], language)

        # load alignment model and metadata
        try:
            model_a, metadata = whisperx.load_align_model(
                language_code=language, device=device, model_name=alignment_model
            )
        except ValueError as ve:
            print(
                f"{red_highlighted(f'{ve}')}"
                f"\n"
                f"{ULTRASINGER_HEAD} {red_highlighted('Error:')} Unknown language. "
                f"Try add it with --align_model [huggingface]."
            )
            raise ve

        print(f"{ULTRASINGER_HEAD} Aligning lyrics to the audio")

        # align whisper output
        result_aligned = whisperx.align(
            segments,
            model_a,
            metadata,
            audio,
            device,
            return_char_alignments=False,
        )

        transcribed_data = convert_to_transcribed_data(result_aligned)

        # Safety net: the aligner sometimes drops words ("backtrack failed").
        # Restore them from the known lyrics so no line disappears.
        if lyrics is not None:
            produced = [
                {"word": item.word.strip(), "start": item.start, "end": item.end}
                for item in transcribed_data
            ]
            repairs = repair_missing_words(lyrics["lines"], produced)
            if repairs:
                transcribed_data.extend(
                    transcribed_data_from_word_timings(
                        [(item["word"], item["start"], item["end"]) for item in repairs],
                        confidence=0.85,
                    )
                )
                transcribed_data.sort(key=lambda item: item.start)
                print(
                    f"{ULTRASINGER_HEAD} {red_highlighted('Restored')} {len(repairs)} word(s) "
                    f"that the aligner dropped, using the timings of your lyrics file"
                )
            expected = sum(len(line.split()) for line in lyrics["lines"])
            if expected and len(transcribed_data) < expected * 0.7:
                print(
                    f"{ULTRASINGER_HEAD} {red_highlighted('Warning:')} only "
                    f"{len(transcribed_data)} of {expected} lyric words got a timing. "
                    f"Try preset 'quality' and check the language setting."
                )

        return TranscriptionResult(transcribed_data, language)
    except ValueError as value_error:
        # Restore original torch.load in case of error
        torch.load = _original_torch_load

        if (
            "Requested float16 compute type, but the target device or backend do not support efficient float16 computation."
            in str(value_error)
        ):
            print(value_error)
            print(
                f"{ULTRASINGER_HEAD} Your GPU does not support efficient float16 computation; run UltraSinger with '--whisper_compute_type int8'"
            )

        raise value_error
    except OutOfMemoryError as oom_exception:
        # Restore original torch.load in case of error
        torch.load = _original_torch_load

        print(oom_exception)
        print(MEMORY_ERROR_MESSAGE)
        raise oom_exception
    except Exception as exception:
        # Restore original torch.load in case of error
        torch.load = _original_torch_load

        if "CUDA failed with error out of memory" in str(exception):
            print(exception)
            print(MEMORY_ERROR_MESSAGE)
        raise exception
    finally:
        # Restore original torch.load after models are loaded
        # This ensures other modules (like pitch detection) are not affected by the monkey-patch
        torch.load = _original_torch_load


def convert_to_transcribed_data(result_aligned):
    transcribed_data = []
    for segment in (result_aligned or {}).get("segments") or []:
        for obj in segment.get("words") or []:
            vtd = from_whisper(obj)  # create custom Word object
            vtd.word = vtd.word + " "  # add space to end of word
            if len(obj) < 4:
                #Addition for numbers to words (Using previous code from louispan in PR#135)
                if len(transcribed_data) == 0: # if the first word doesn't have any timing data
                    vtd.start = 0.0
                    vtd.end = 0.1
                    msg = f'Error: There is no timestamp for word: "{obj["word"]}". ' \
                        f'Fixing it by placing it at beginning. At start: {vtd.start} end: {vtd.end}. Fix it manually!'
                else:
                    previous = transcribed_data[-1] if len(transcribed_data) != 0 else TranscribedData()
                    vtd.start = previous.end + 0.1
                    vtd.end = previous.end + 0.2
                    msg = f'Error: There is no timestamp for word: "{obj["word"]}". ' \
                          f'Fixing it by placing it after the previous word: "{previous.word}". At start: {vtd.start} end: {vtd.end}. Fix it manually!'
                print(f"{red_highlighted(msg)}")
            transcribed_data.append(vtd)  # and add it to list
    return transcribed_data
