"""Midi creator module"""

import math
import os
from collections import Counter

import librosa
import numpy as np
import pretty_midi
import unidecode

from modules.Midi.MidiSegment import MidiSegment
from modules.Speech_Recognition.TranscribedData import TranscribedData
from modules.console_colors import (
    ULTRASINGER_HEAD, blue_highlighted,
)
from modules.Ultrastar.ultrastar_txt import UltrastarTxtValue
from modules.Pitcher.pitched_data import PitchedData
from modules.Pitcher.pitched_data_helper import get_frequencies_with_high_confidence
from modules.Audio.key_detector import quantize_note_to_key

# SwiftF0's model ceiling is ~2093 Hz (C7). Unvoiced onsets often land there
# and become UltraStar pitch 48 — notes that fly off the USDX staff.
# Keep only frequencies a human can actually sing.
VOCAL_FMIN_HZ = 65.0    # ~C2
VOCAL_FMAX_HZ = 1046.5  # C6
# MIDI window used as "this could be a real sung note" when finding tessitura.
VOCAL_MIDI_LO = 40      # E2
VOCAL_MIDI_HI = 84      # C6
# Hard clamp after octave folding (G#1 .. E6).
MIDI_CLAMP_LO = 28
MIDI_CLAMP_HI = 88

def create_midi_instrument(midi_segments: list[MidiSegment]) -> object:
    """Converts an Ultrastar data to a midi instrument"""

    print(f"{ULTRASINGER_HEAD} Creating midi instrument")

    instrument = pretty_midi.Instrument(program=0, name="Vocals")
    velocity = 100

    for i, midi_segment in enumerate(midi_segments):
        note = pretty_midi.Note(velocity, librosa.note_to_midi(midi_segment.note), midi_segment.start, midi_segment.end)
        instrument.notes.append(note)

    return instrument

def sanitize_for_midi(text):
    """
    Sanitize text for MIDI compatibility.
    Uses unidecode to approximate characters to ASCII.
    """
    return unidecode.unidecode(text)

def __create_midi(instruments: list[object], bpm: float, midi_output: str, midi_segments: list[MidiSegment]) -> None:
    """Write instruments to midi file"""

    print(f"{ULTRASINGER_HEAD} Creating midi file -> {midi_output}")

    midi_data = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    for i, midi_segment in enumerate(midi_segments):
        sanitized_word = sanitize_for_midi(midi_segment.word)
        midi_data.lyrics.append(pretty_midi.Lyric(text=sanitized_word, time=midi_segment.start))
    for instrument in instruments:
        midi_data.instruments.append(instrument)
    midi_data.write(midi_output)


class MidiCreator:
    """Docstring"""


def convert_frequencies_to_notes(frequency: [str]) -> list[list[str]]:
    """Converts frequencies to notes"""
    notes = []
    for freq in frequency:
        notes.append(librosa.hz_to_note(float(freq)))
    return notes


def most_frequent(array: [str]) -> list[tuple[str, int]]:
    """Get most frequent item in array"""
    return Counter(array).most_common(1)


def find_nearest_index(array: list[float], value: float) -> int:
    """Nearest index in array"""
    idx = np.searchsorted(array, value, side="left")
    if idx > 0 and (
        idx == len(array)
        or math.fabs(value - array[idx - 1]) < math.fabs(value - array[idx])
    ):
        return idx - 1

    return idx


def _voiced_frequencies(freqs, confs) -> list[float]:
    """Keep confident frames inside the singable band. Never fall back to fmax spikes."""
    in_range = []
    for freq, conf in zip(freqs, confs):
        try:
            f = float(freq)
        except (TypeError, ValueError):
            continue
        if VOCAL_FMIN_HZ <= f <= VOCAL_FMAX_HZ:
            in_range.append((f, float(conf) if conf is not None else 0.0))
    for threshold in (0.5, 0.35, 0.0):
        picked = [f for f, c in in_range if c >= threshold]
        if picked:
            return picked
    return []


def fold_midi_sequence(midis: list[int]) -> tuple[list[int], int]:
    """Fold octave errors into the song tessitura and limit wild leaps.

    Each note is tried in nearby octaves; we pick the candidate closest to the
    previous note, with a pull toward the song's median sung pitch.
    """
    if not midis:
        return [], 60

    vocal = [m for m in midis if VOCAL_MIDI_LO <= m <= VOCAL_MIDI_HI]
    if len(vocal) < max(3, len(midis) // 10):
        vocal = list(midis)
    center = int(round(float(np.median(vocal))))

    prev = center
    folded = []
    for raw in midis:
        best = raw
        best_score = 10 ** 9
        for k in range(-5, 6):
            cand = int(raw) + 12 * k
            if cand < MIDI_CLAMP_LO or cand > MIDI_CLAMP_HI:
                continue
            jump = abs(cand - prev)
            score = jump * 3 + abs(cand - center)
            if jump > 7:
                score += (jump - 7) * 4
            if score < best_score:
                best_score = score
                best = cand
        folded.append(int(best))
        prev = best
    return folded, center


def stabilize_midi_octaves(midi_segments: list[MidiSegment]) -> list[MidiSegment]:
    """Rewrite note names so octave jumps (C7 spikes, dropped octaves) disappear."""
    if not midi_segments:
        return midi_segments

    midis = []
    for seg in midi_segments:
        try:
            midis.append(int(round(librosa.note_to_midi(seg.note))))
        except Exception:
            midis.append(60)

    folded, center = fold_midi_sequence(midis)
    try:
        tessitura = librosa.midi_to_note(center)
    except Exception:
        tessitura = str(center)
    print(
        f"{ULTRASINGER_HEAD} Stabilizing pitches around tessitura "
        f"{blue_highlighted(tessitura)}"
    )

    for seg, midi_val in zip(midi_segments, folded):
        try:
            seg.note = librosa.midi_to_note(int(midi_val))
        except Exception:
            pass
    return midi_segments


def create_midi_notes_from_pitched_data(start_times: list[float], end_times: list[float], words: list[str],
                                         pitched_data: PitchedData, allowed_notes: set[str] = None) -> list[MidiSegment]:
    """Create midi notes from pitched data

    Args:
        start_times: List of start times
        end_times: List of end times
        words: List of words/syllables
        pitched_data: Pitched data containing frequencies and confidence
        allowed_notes: Optional set of allowed note names for key quantization

    Returns:
        List of MidiSegments
    """
    print(f"{ULTRASINGER_HEAD} Creating midi_segments")

    midi_segments = []

    for index, start_time in enumerate(start_times):
        end_time = end_times[index]
        word = str(words[index])

        midi_segment = create_midi_note_from_pitched_data(start_time, end_time, pitched_data, word, allowed_notes)
        midi_segments.append(midi_segment)

        # todo: Progress?
        # print(filename + " f: " + str(mean))

    midi_segments = stabilize_midi_octaves(midi_segments)
    return midi_segments


def create_midi_note_from_pitched_data(start_time: float, end_time: float, pitched_data: PitchedData, word: str,
                                        allowed_notes: set[str] = None) -> MidiSegment:
    """Create midi note from pitched data

    Args:
        start_time: Start time of the note
        end_time: End time of the note
        pitched_data: Pitched data containing frequencies and confidence
        word: The word/syllable for this note
        allowed_notes: Optional set of allowed note names (without octave) for key quantization

    Returns:
        One MidiSegment
    """

    start = find_nearest_index(pitched_data.times, start_time)
    end = find_nearest_index(pitched_data.times, end_time)

    if start == end:
        freqs = [pitched_data.frequencies[start]]
        confs = [pitched_data.confidence[start]]
    else:
        freqs = pitched_data.frequencies[start:end]
        confs = pitched_data.confidence[start:end]

    conf_f = _voiced_frequencies(freqs, confs)

    if conf_f:
        midi_vals = librosa.hz_to_midi(np.asarray(conf_f, dtype=float))
        midi_note = int(round(float(np.median(midi_vals))))
        midi_note = max(0, min(127, midi_note))
        note = librosa.midi_to_note(midi_note)
    else:
        # No voiced frame in this syllable (silence / tracker spike). C4 is a
        # placeholder; stabilize_midi_octaves folds it into the song tessitura.
        note = "C4"

    if allowed_notes is not None:
        note = quantize_note_to_key(note, allowed_notes)

    return MidiSegment(note, start_time, end_time, word)


def create_midi_segments_from_transcribed_data(transcribed_data: list[TranscribedData], pitched_data: PitchedData,
                                                allowed_notes: set[str] = None) -> list[MidiSegment]:
    """Create MIDI segments from transcribed data

    Args:
        transcribed_data: List of transcribed data segments
        pitched_data: Pitched data containing frequencies and confidence
        allowed_notes: Optional set of allowed note names for key quantization

    Returns:
        List of MidiSegments
    """
    start_times = []
    end_times = []
    words = []

    if transcribed_data:
        for i, midi_segment in enumerate(transcribed_data):
            start_times.append(midi_segment.start)
            end_times.append(midi_segment.end)
            words.append(midi_segment.word)
        midi_segments = create_midi_notes_from_pitched_data(start_times, end_times, words,
                                                            pitched_data, allowed_notes)
        return midi_segments


def create_repitched_midi_segments_from_ultrastar_txt(pitched_data: PitchedData, ultrastar_txt: UltrastarTxtValue) -> list[MidiSegment]:
    start_times = []
    end_times = []
    words = []

    for i, note_lines in enumerate(ultrastar_txt.UltrastarNoteLines):
        start_times.append(note_lines.startTime)
        end_times.append(note_lines.endTime)
        words.append(note_lines.word)
    midi_segments = create_midi_notes_from_pitched_data(start_times, end_times, words, pitched_data)
    return midi_segments


def create_midi_file(
        real_bpm: float,
        song_output: str,
        midi_segments: list[MidiSegment],
        basename_without_ext: str,
) -> None:
    """Create midi file"""
    print(f"{ULTRASINGER_HEAD} Creating Midi with {blue_highlighted('pretty_midi')}")

    voice_instrument = [
        create_midi_instrument(midi_segments)
    ]

    midi_output = os.path.join(song_output, f"{basename_without_ext}.mid")
    __create_midi(voice_instrument, real_bpm, midi_output, midi_segments)
