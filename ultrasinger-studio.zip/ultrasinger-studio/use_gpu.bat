@echo off
title UltraSinger Studio - enable NVIDIA GPU
cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" goto noenv
if not exist "tools\uv\uv.exe" goto noenv

echo ============================================================
echo   Switching torch to the GPU build for NVIDIA cards.
echo   Supported here: GTX 10xx / 16xx and newer.
echo   This downloads about 3 GB. Be patient.
echo ============================================================
echo.

tools\uv\uv.exe pip install -p "venv\Scripts\python.exe" --reinstall --torch-backend=cu126 torch==2.8.0 torchaudio==2.8.0 torchvision==0.23.0 numpy==2.4.2
if errorlevel 1 goto failed

rem Forget the previous Whisper device check, so it is probed again
if exist "data\models\.whisper_gpu.json" del "data\models\.whisper_gpu.json" >nul 2>nul

echo.
echo ============================================================
echo   Checking the video driver and the GPU.
echo ============================================================
echo.
venv\Scripts\python.exe -c "import torch; print('torch:', torch.__version__); print('CUDA runtime:', torch.version.cuda); print('GPU available:', torch.cuda.is_available())"
echo.
echo   If GPU available is True, start.bat will use the video card.
echo   If it is False, update the NVIDIA driver, then run this file again.
echo.
pause
exit /b 0

:failed
echo.
echo [ERROR] Could not install the GPU build.
echo Check internet and antivirus, then run use_gpu.bat again.
echo.
pause
exit /b 1

:noenv
echo.
echo [ERROR] Environment not found. Run install.bat first.
echo.
pause
exit /b 1
