@echo off
title UltraSinger Studio - HuggingFace mirror
cd /d "%~dp0"

if exist "hf_mirror.on" goto disable

echo ============================================================
echo   Enabling the HuggingFace mirror (hf-mirror.com).
echo   Use this when AI models fail to download from
echo   huggingface.co: "Read timed out" or very slow speed.
echo   The mirror is a copy of the same models.
echo ============================================================
echo.
echo HuggingFace mirror enabled. > "hf_mirror.on"
echo   Done: models will be downloaded from hf-mirror.com
echo   start.bat and make.bat pick this up automatically.
echo.
echo   Run use_hf_mirror.bat again to switch back.
pause
exit /b 0

:disable
del "hf_mirror.on" >nul 2>nul
echo.
echo   HuggingFace mirror disabled: back to huggingface.co
echo.
pause
exit /b 0
