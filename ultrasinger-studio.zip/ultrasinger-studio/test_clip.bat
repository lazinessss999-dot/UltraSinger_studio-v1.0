@echo off
title UltraSinger Studio - quick test clip
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "ffmpeg\bin\ffmpeg.exe" goto noffmpeg
if not exist "venv\Scripts\python.exe" goto noenv
if "%~1"=="" goto usage

set "SRC=%~1"
if not exist "%SRC%" goto nofile

if not exist "test_audio" mkdir "test_audio"

echo ============================================================
echo   Making a 40 second clip for a quick pipeline test.
echo   Source: %SRC%
echo ============================================================
echo.

ffmpeg\bin\ffmpeg.exe -hide_banner -loglevel error -y -ss 30 -t 40 -i "%SRC%" -vn -c:a libmp3lame -q:a 2 "test_audio\clip.mp3"
if errorlevel 1 goto failed

echo   Clip ready: test_audio\clip.mp3
echo.
echo   Open start.bat and use this clip: the full pipeline on
echo   40 seconds takes 1 to 2 minutes instead of 20, so mistakes
echo   are found much faster. When it works, run the whole song.
echo.
pause
exit /b 0

:usage
echo.
echo   Usage: test_clip.bat "H:\Karaoke\mp3\song.mp3"
echo.
echo   Creates test_audio\clip.mp3, a 40 second fragment, to check
echo   the whole pipeline quickly before processing a full song.
echo.
pause
exit /b 1

:failed
echo.
echo [ERROR] Could not create the clip. Check that the file is a
echo         real audio file and that the path is correct.
echo.
pause
exit /b 1

:noffmpeg
echo [ERROR] ffmpeg is not installed yet. Run install.bat first.
pause
exit /b 1

:noenv
echo [ERROR] Environment not found. Run install.bat first.
pause
exit /b 1

:nofile
echo.
echo [ERROR] File not found: %SRC%
echo.
pause
exit /b 1
