@echo off
title UltraSinger Studio - Stop
cd /d "%~dp0"

netstat -ano | findstr "127.0.0.1:8000" | findstr "LISTENING" >nul 2>nul
if errorlevel 1 goto notrunning

echo Stopping the web server on port 8000 ...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"

timeout /t 2 /nobreak >nul
netstat -ano | findstr "127.0.0.1:8000" | findstr "LISTENING" >nul 2>nul
if errorlevel 1 goto stopped

echo.
echo   Could not stop the server automatically.
echo   Close the window titled "UltraSinger Studio" and try again.
echo.
pause
exit /b 1

:stopped
echo   Server stopped.
timeout /t 2 /nobreak >nul
exit /b 0

:notrunning
echo.
echo   No server is running on port 8000.
timeout /t 3 /nobreak >nul
exit /b 0
