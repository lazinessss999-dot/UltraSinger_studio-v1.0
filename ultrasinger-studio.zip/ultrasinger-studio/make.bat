@echo off
setlocal EnableExtensions
title UltraSinger Studio - Console

set "USROOT=%~dp0"
if "%USROOT:~-1%"=="\" set "USROOT=%USROOT:~0,-1%"

if "%~1"=="" goto usage
if not exist "%USROOT%\venv\Scripts\python.exe" goto noenv

set "FILE=%~1"
shift

set "PATH=%USROOT%\ffmpeg\bin;%USROOT%\venv\Scripts;%PATH%"
set "HF_HOME=%USROOT%\data\models\hf"
set "TORCH_HOME=%USROOT%\data\models\torch"
set "NLTK_DATA=%USROOT%\data\models\nltk"
set "PYTHONUTF8=1"
set "HF_HUB_DOWNLOAD_TIMEOUT=90"
set "HF_HUB_ETAG_TIMEOUT=90"
if exist "%USROOT%\hf_mirror.on" set "HF_ENDPOINT=https://hf-mirror.com"

cd /d "%USROOT%\UltraSinger-src\src"
"%USROOT%\venv\Scripts\python.exe" UltraSinger.py %* -i "%FILE%" -o "%USROOT%\data\cli_output"
echo.
pause
exit /b 0

:usage
echo.
echo Usage:
echo   make.bat "path\to\song.mp3" [extra options]
echo.
echo Examples:
echo   make.bat "H:\Karaoke\mp3\song.mp3"
echo   make.bat "H:\Karaoke\mp3\song.mp3" --whisper base
echo   make.bat "H:\Karaoke\mp3\song.mp3" --whisper medium --force_cpu
echo.
echo Useful options:
echo   --whisper        tiny, base, small, medium, large-v2
echo   --language ru    force language, e.g. Russian
echo   --disable_separation  skip demucs, faster
echo   --force_cpu      run everything on CPU
echo   --keep_cache     keep the cache folder
echo   --format_version 1.2.0
echo.
echo Results go to: %USROOT%\data\cli_output
echo.
pause
exit /b 1

:noenv
echo [ERROR] Environment not found. Run install.bat first.
pause
exit /b 1
